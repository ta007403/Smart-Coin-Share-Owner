from PyQt5.QtCore import QThread, pyqtSignal
import requests
import time
import threading
import os
from utils import config
from dotenv import load_dotenv

load_dotenv()

BTC_PRICE_API = os.getenv("BTC_PRICE_API")
if BTC_PRICE_API is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

SATOSHIS_PER_BTC = 100_000_000

class BTCPriceFetcher(QThread):
    price_updated = pyqtSignal(float)
    global BTC_PRICE_API

    def __init__(self, api_url=None, refresh_interval=300):
        super().__init__()
        self.api_url = api_url or os.getenv("BTC_PRICE_API", "https://www.lntopup.com/wp-json/lntopup/v1/btc-oracle") # This is default price oracle
        self.refresh_interval = refresh_interval
        self.btc_thb = None
        self.sats_per_thb = None
        self._lock = threading.Lock()
        self._running = True
        self._paused = False
        self._last_fetch_time = 0
        self.name = "BTCPriceFetcher"

    def run(self):
        threading.current_thread().name = self.name
        while self._running:
            if self._paused:
                time.sleep(0.5)
                continue

            now = time.time()
            elapsed = now - self._last_fetch_time
            if elapsed < self.refresh_interval:
                wait_time = self.refresh_interval - elapsed
                # Wait in small steps so pause/resume is responsive
                for _ in range(int(wait_time * 2)):
                    if self._paused or not self._running:
                        break
                    time.sleep(0.5)
                continue

            self.fetch_price()
            price = self.get_btc_price_thb()
            if price is not None:
                self.price_updated.emit(price)
                print(f"[BTC] Emitted: {price}")
            self._last_fetch_time = time.time()

    def fetch_price(self, retries=2, delay=2):
        last_good_btc_thb = self.btc_thb  # Keep for comparison/sanity
        for attempt in range(retries + 1):
            try:
                response = requests.get(self.api_url, timeout=5)
                data = response.json()
                btc_thb = data["THB_BTC"]["last"]

                # === Sanity check ===
                # Avoid updating if price is totally wrong or None
                if not isinstance(btc_thb, (int, float)):
                    raise ValueError(f"BTC price is not a number: {btc_thb}")
                if not (100_000 < btc_thb < 10_000_000):
                    raise ValueError(f"Unrealistic BTC price: {btc_thb}")

                sats_per_thb = round(SATOSHIS_PER_BTC / btc_thb)
                with self._lock:
                    self.btc_thb = btc_thb
                    config.BTC_THB = btc_thb
                    self.sats_per_thb = sats_per_thb
                    config.SATS_PER_THB = sats_per_thb
                print(f"[BTC] Updated: 1 BTC = {btc_thb} THB, 1 THB = {sats_per_thb} sats")
                return True
            except Exception as e:
                print(f"[BTC] Fetch error (attempt {attempt+1}): {e}")
                if attempt < retries:
                    time.sleep(delay)
        # If all attempts fail, don’t update the price, stick to last_good_btc_thb
        print("[BTC] All attempts to fetch BTC price failed. Using last known value:", last_good_btc_thb)
        return False

    def get_btc_price_thb(self):
        with self._lock:
            return self.btc_thb

    def get_sats_per_thb(self):
        with self._lock:
            return self.sats_per_thb

    def pause(self):
        print("BTC price paused")
        self._paused = True

    def resume(self):
        print("BTC price resumed")
        self._paused = False

    def stop(self):
        print("BTC price fetcher stopped")
        self._running = False
        self.wait()
