from multiprocessing import Process
import serial
import serial.threaded
import time

NOTE_VALUES = {
    b'\x81\x44': 1000,
    b'\x81\x43': 500,
    b'\x81\x42': 100,
    b'\x81\x41': 50,
    b'\x81\x40': 20
}

class BillAcceptorProtocol(serial.threaded.Protocol):
    """
    Runs inside ReaderThread, handles data_received events automatically.
    """
    def __init__(self, result_queue):
        super().__init__()
        self.result_queue = result_queue
        self.buffer = bytearray()
        self.last_note_value = None
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport
        self.result_queue.put(("info", "Bill acceptor protocol connected"))

    def data_received(self, data):
        self.result_queue.put(("debug", f"RAW: {data.hex()}"))
        self.buffer.extend(data)

        while True:

            # --- STEP 1: handle confirm FIRST ---
            if len(self.buffer) >= 1 and self.buffer[0] == 0x10:
                self.result_queue.put(("debug", "CONFIRM 0x10 received"))

                if self.last_note_value is not None:
                    self.result_queue.put(("note", self.last_note_value))
                    self.result_queue.put(("info", f"{self.last_note_value} THB stacked (emit)"))
                    self.last_note_value = None

                self.buffer.pop(0)
                continue

            # --- STEP 2: need at least 2 bytes for note ---
            if len(self.buffer) < 2:
                return

            frame = bytes(self.buffer[:2])

            # --- STEP 3: valid note ---
            if frame in NOTE_VALUES:
                value = NOTE_VALUES[frame]

                self.last_note_value = value
                self.result_queue.put(("info", f"Note detected: {value} THB"))

                try:
                    self.result_queue.put(("sound", "cha_ching"))
                    self.transport.write(b'\x02')   # ACK immediately
                    self.result_queue.put(("debug", "SENT 0x02 (stack cmd)"))
                except Exception as e:
                    self.result_queue.put(("error", f"Stack send failed: {e}"))

                del self.buffer[:2]
                continue

            # --- STEP 4: resync (safe) ---
            found = False
            for i in range(1, len(self.buffer) - 1):
                if bytes(self.buffer[i:i+2]) in NOTE_VALUES:
                    for _ in range(i):
                        dropped = self.buffer.pop(0)
                        self.result_queue.put(("debug", f"Shift byte {dropped:02x}"))
                    found = True
                    break

            if not found:
                dropped = self.buffer.pop(0)
                self.result_queue.put(("debug", f"Dropped stray byte {dropped:02x}"))

    def connection_lost(self, exc):
        if exc:
            self.result_queue.put(("error", f"Bill acceptor connection lost: {exc}"))
        else:
            self.result_queue.put(("info", "Bill acceptor connection closed"))


class BillAcceptorProcess(Process):
    """
    Multiprocessing wrapper around the threaded ReaderThread protocol.
    """
    def __init__(self, port, baudrate=9600, result_queue=None, command_queue=None):
        super().__init__()
        self.port = port
        self.baudrate = baudrate
        self.result_queue = result_queue
        self.command_queue = command_queue
        self.reader_thread = None

    def run(self):
        ser = None
        try:
            try:
                ser = serial.Serial(
                    self.port,
                    self.baudrate,
                    bytesize=serial.EIGHTBITS,
                    parity=serial.PARITY_EVEN,
                    stopbits=serial.STOPBITS_ONE,
                    timeout=0   # non-blocking
                )
                self.result_queue.put(("info", "Bill acceptor process ready"))
            except Exception as e:
                self.result_queue.put(("error", f"Serial open failed: {e}"))
                return

            with serial.threaded.ReaderThread(ser, lambda: BillAcceptorProtocol(self.result_queue)) as protocol:
                while True:
                    if self.command_queue is not None:
                        while not self.command_queue.empty():
                            cmd = self.command_queue.get_nowait()
                            self.result_queue.put(("debug", f"COMMAND: {cmd}"))
                            if cmd == "enable":
                                try:
                                    ser.write(b'\x02')  # enable
                                    ser.flush()
                                    time.sleep(0.1)
                                    self.result_queue.put(("info", "Bill acceptor ENABLED"))
                                except Exception as e:
                                    self.result_queue.put(("error", f"Enable: {e}"))
                            elif cmd == "disable":
                                try:
                                    ser.write(b'\x5E')  # disable
                                    ser.flush()
                                    time.sleep(0.1)
                                    self.result_queue.put(("info", "Bill acceptor DISABLED"))
                                except Exception as e:
                                    self.result_queue.put(("error", f"Disable: {e}"))
                            elif cmd == "exit":
                                return

                    time.sleep(0.05)

        except Exception as e:
            self.result_queue.put(("error", f"Process crashed: {e}"))
        finally:
            if ser and ser.is_open:
                ser.close()
