def can_dispense(amount, note_stock):
    """
    amount: int - the amount to dispense
    note_stock: dict - notes available, e.g. {1000: 1, 500: 0, 100: 5}
    Returns True if possible to dispense, else False
    """
    remaining = amount
    stock = note_stock.copy()
    for note in sorted(stock.keys(), reverse=True):
        take = min(remaining // note, stock[note])
        remaining -= take * note
    return remaining == 0

def available_buttons(note_stock, amounts):
    available = []
    for amt in amounts:
        if get_banknote_breakdown(amt, note_stock):
            available.append(amt)
    return available

def get_banknote_breakdown(amount, note_stock):
    # note_stock: {100: 48, 500: 0, 1000: 0}
    result = {100: 0, 500: 0, 1000: 0}
    for denom in sorted(note_stock.keys(), reverse=True):
        # Max notes we can use (limited by amount and stock)
        max_notes = min(amount // denom, note_stock[denom])
        result[denom] = max_notes
        amount -= max_notes * denom
    if amount == 0:
        return result
    else:
        # Not possible to dispense with available stock
        return None

# Example stock:
#note_stock = {1000: 1, 500: 0, 100: 5}

# Example: Test which amounts can be dispensed
#buttons = [100*i for i in range(1, 11)]

#for amt in buttons:
#    print(f"{amt}: {'Show' if can_dispense(amt, note_stock) else 'Hide'}")

# Example for reverse checking:
#print("This is all avialable button with remain banknotes")
#print(available_buttons(note_stock, buttons))