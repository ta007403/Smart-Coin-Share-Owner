from multiprocessing import Process
import serial
import serial.threaded
import time

# Mapping coin channels to THB values
CHANNEL_TO_THAI_BAHT = {
    0x04: 10,
    0x03: 5,
    0x05: 2,
    0x02: 2,
    0x06: 1,
    0x01: 1
}

class CoinAcceptorProtocol(serial.threaded.Protocol):
    def __init__(self, result_queue):
        super().__init__()
        self.result_queue = result_queue
        self.buffer = bytearray()

    def connection_made(self, transport):
        self.transport = transport
        self.result_queue.put(("info", "Coin acceptor protocol connected"))

    def data_received(self, data):
        FRAME_LEN = 6

        self.buffer.extend(data)

        while len(self.buffer) >= FRAME_LEN:

            # sync to header
            if self.buffer[0] != 0x90:
                self.buffer.pop(0)
                continue

            frame = bytes(self.buffer[:FRAME_LEN])

            # 🔥 VALIDATE FRAME STRUCTURE
            # Expected: 90 06 12 XX 03 XX
            if not (
                frame[0] == 0x90 and
                frame[1] == 0x06 and
                frame[2] == 0x12 and
                frame[4] == 0x03
            ):
                # invalid frame → shift 1 byte
                self.buffer.pop(0)
                continue

            # valid frame → consume it
            del self.buffer[:FRAME_LEN]

            self.result_queue.put(("debug", f"FULL FRAME: {frame.hex()}"))

            coin_code = frame[3]
            value = CHANNEL_TO_THAI_BAHT.get(coin_code)

            if value is not None:
                self.result_queue.put(("coin", value))
            else:
                self.result_queue.put(("error", f"Unknown channel {coin_code}"))

class CoinAcceptorProcess(Process):
    """
    Multiprocessing wrapper around ReaderThread protocol.
    """
    def __init__(self, port, baudrate=9600, result_queue=None, command_queue=None):
        super().__init__()
        self.port = port
        self.baudrate = baudrate
        self.result_queue = result_queue
        self.command_queue = command_queue

    def run(self):
        ser = None
        try:
            try:
                ser = serial.Serial(
                    self.port,
                    self.baudrate,
                    bytesize=serial.EIGHTBITS,
                    parity=serial.PARITY_EVEN,
                    stopbits=serial.STOPBITS_ONE,
                    timeout=0 # NON-BLOCKING
                )

                ser.reset_input_buffer()
                ser.reset_output_buffer()

                self.result_queue.put(("info", "Coin acceptor process ready"))
            except Exception as e:
                self.result_queue.put(("error", f"Serial open failed: {e}"))
                return

            with serial.threaded.ReaderThread(ser, lambda: CoinAcceptorProtocol(self.result_queue)) as protocol:
                while True:
                    if self.command_queue is not None:
                        while not self.command_queue.empty():
                            cmd = self.command_queue.get_nowait()
                            if cmd == "enable":
                                try:
                                    self._send_command(ser, 0x01, "enable")
                                    self.result_queue.put(("info", "Coin acceptor ENABLED"))
                                except Exception as e:
                                    self.result_queue.put(("error", f"Enable: {e}"))
                            elif cmd == "disable":
                                try:
                                    self._send_command(ser, 0x02, "disable")
                                    self.result_queue.put(("info", "Coin acceptor DISABLED"))
                                except Exception as e:
                                    self.result_queue.put(("error", f"Disable: {e}"))
                            elif cmd == "exit":
                                return
                    time.sleep(0.005)

        except Exception as e:
            if self.result_queue:
                self.result_queue.put(("error", f"Process crashed: {e}"))
        finally:
            if ser and ser.is_open:
                ser.close()

    def _send_command(self, ser, CMD, label, EXT=0x03):
        """Helper: build and send command frame to coin acceptor."""
        SYNC = 0x90
        LNG = 0x05
        CHECKSUM = (SYNC + LNG + CMD + EXT) & 0xFF
        cmd_bytes = bytes([SYNC, LNG, CMD, EXT, CHECKSUM])
        ser.write(cmd_bytes)
        ser.flush()
        self.result_queue.put(("debug", f"Sent {label} command: {cmd_bytes.hex()}"))
