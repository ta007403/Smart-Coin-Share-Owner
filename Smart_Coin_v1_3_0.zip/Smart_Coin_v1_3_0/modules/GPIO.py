import RPi.GPIO as GPIO

class GPIOMgr:
    def __init__(self):
        GPIO.setmode(GPIO.BCM)  # Use BCM pin numbering
        GPIO.setwarnings(False)
        self.initialized_pins = set()

    def set_pin(self, pin, value):
        if pin not in self.initialized_pins:
            GPIO.setup(pin, GPIO.OUT)
            self.initialized_pins.add(pin)
        GPIO.output(pin, GPIO.HIGH if value else GPIO.LOW)
        #print(f"Setting GPIO pin {pin} to {'HIGH' if value else 'LOW'}")

    def enable_coin_acceptor(self, on: bool):
        """
        Enables or disables the coin acceptor connected to GPIO 17.
        :param on: True to enable, False to disable.
        """
        self.set_pin(17, on)

    def set_led(self, on: bool):
        """
        Turns the LED on or off connected to GPIO 27.
        :param on: True to turn on, False to turn off.
        """
        self.set_pin(27, on)

# Usage example:
#gpio = GPIOMgr()
#gpio.set_pin(17, 1)  # Set pin 17 HIGH (on)
#gpio.set_pin(17, 0)  # Set pin 17 LOW (off)
#gpio.enable_coin_acceptor(True)   # Enable coin acceptor
#gpio.enable_coin_acceptor(False)  # Disable coin acceptor
#gpio.set_led(True)                # Turn LED on
#gpio.set_led(False)               # Turn LED off