from PyQt5.QtCore import QThread, pyqtSignal
import threading
import serial
import time
import re
from datetime import datetime, timedelta

class ArduinoSMSAndReadWorker(QThread):
    cmti_detected = pyqtSignal(str, int)    # emits the +CMTI line and index
    arduino_line = pyqtSignal(str)          # emits every line read (optional)
    sms_parsed = pyqtSignal(dict)           # emits parsed SMS result
    finished = pyqtSignal()                 # worker is done

    def __init__(self, port, baudrate=9600, stop_flag_func=None, parent=None):
        super().__init__(parent)
        self.port = port
        self.baudrate = baudrate
        self._running = True
        self._stop_flag_func = stop_flag_func
        self.name = "GSM_Module"

    def run(self):
        threading.current_thread().name = self.name
        self.serial_GSM_Module = serial.Serial(
            self.port,
            self.baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.2
        )
        print("Listening for Arduino feedback (waiting for +CMTI)...")
        responses = []
        sms_index = None

        while self._running:
            if self._stop_flag_func and self._stop_flag_func():
                print("[INFO] Listening stopped externally.")
                break

            if self.serial_GSM_Module.in_waiting:
                line = self.serial_GSM_Module.readline().decode(errors='ignore').strip()
                if line:
                    print("<<", line)
                    responses.append(line)
                    self.arduino_line.emit(line)
                    # Detect +CMTI and extract index
                    cmti_match = re.search(r'\+CMTI:\s*"SM",\s*(\d+)', line)
                    if cmti_match:
                        sms_index = int(cmti_match.group(1))
                        print(f"SMS Notification Detected (+CMTI), index={sms_index}")
                        self.cmti_detected.emit(line, sms_index)
                        break
            else:
                time.sleep(0.1)

        # If index found, run the read command
        if sms_index is not None:
            result = self.send_read_command(self.serial_GSM_Module, sms_index)
            if result:
                self.sms_parsed.emit(result)

        self.finished.emit()

    def stop(self):
        print("[INFO] Stopping ArduinoSMSAndReadWorker...")
        self._running = False
        self.wait()

    @staticmethod
    def send_read_command(ser, index):
        """
        Sends 'READ <index>' to Arduino via `ser`, expects structured SMS summary response.
        Returns dict with parsed data.
        """
        command = f"READ {index}\n"
        ser.flushInput()
        ser.write(command.encode())
        print(f">> Sent: {command.strip()}")

        response = []
        start = time.time()
        timeout = 5  # seconds

        print("<< Waiting for response...")
        while time.time() - start < timeout:
            if ser.in_waiting:
                line = ser.readline().decode(errors='ignore').strip()
                if line:
                    print("<<", line)
                    response.append(line)
                    if "As DateTime" in line:
                        break
            else:
                time.sleep(0.1)

        if not response:
            print("No response from Arduino.")
            return None

        # === Parse Structured Response ===
        result = {}
        for line in response:
            if "KBank SMS detected" in line:
                result["is_kbank"] = True
            elif "Amount:" in line:
                try:
                    result["amount"] = float(line.split(":")[1].strip())
                except:
                    result["amount"] = None
            elif "From:" in line:
                result["sender"] = line.split(":")[1].strip()
            elif "SMS Timestamp (Unix):" in line:
                try:
                    result["timestamp"] = int(line.split(":")[1].strip())
                except:
                    result["timestamp"] = None
            elif "As DateTime:" in line:
                dt_match = re.search(r"As DateTime:\s+(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{1,2})", line)
                if dt_match:
                    d, m, y, h, mi = map(int, dt_match.groups())
                    dt = datetime(y, m, d, h, mi)
                    result["datetime"] = dt
                    result["older_than_10_min"] = datetime.now() - dt > timedelta(minutes=10)

        if "is_kbank" in result:
            # print("Parsed KBank SMS:")
            # print(f"  Amount   : {result.get('amount')}")
            # print(f"  From     : {result.get('sender')}")
            # print(f"  UnixTime : {result.get('timestamp')}")
            # print(f"  DateTime : {result.get('datetime')}")
            # print(f"  > Older than 10 min? {'Yes' if result.get('older_than_10_min') else 'No'}")
            return result

        print("KBank SMS not detected in response.")
        return None

class ArduinoCheckStatusWorker(QThread):
    arduino_status = pyqtSignal(list)       # emits full STATUS response as a list of lines

    def __init__(self, port, baudrate=9600, stop_flag_func=None, parent=None):
        super().__init__(parent)
        self.port = port
        self.baudrate = baudrate
        self._running = True
        self._stop_flag_func = stop_flag_func
        self.ser = None
        self.name = "Arduino_Check"

    def run(self):
        threading.current_thread().name = self.name
        self.ser = serial.Serial(
            self.port,
            self.baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.2
        )
        print("Ready to check status")
        time.sleep(5)
        self.request_status()

    def request_status(self, timeout=2):
        """Send STATUS command to Arduino and emit each line + the full status as a list."""
        if self.ser is None or not self.ser.is_open:
            try:
                self.ser = serial.Serial(self.port, self.baudrate, timeout=1)
            except Exception as e:
                print(f"[ArduinoWorker] Can't open serial: {e}")
                return

        try:
            self.ser.flushInput()
            self.ser.write(b'STATUS\n')
            print("[ArduinoWorker] >> Sent: STATUS")
            response = []
            start = time.time()
            while time.time() - start < timeout:
                if self.ser.in_waiting:
                    line = self.ser.readline().decode(errors='ignore').strip()
                    if line:
                        print("[ArduinoWorker] <<", line)
                        response.append(line)
                    if line in ("OK", "DONE", "STATUS_DONE"):
                        break
                else:
                    time.sleep(0.05)
            self.arduino_status.emit(response)
        except Exception as e:
            print(f"[ArduinoWorker] Error reading STATUS: {e}")

# This class is for delete SMS worker
class ArduinoSMSDeleteWorker(QThread):
    delete_done = pyqtSignal(list)  # emits list of response lines (could be empty)

    def __init__(self, ser, stop_flag_func=None, parent=None):
        """
        :param ser: an already-open serial.Serial object (just like your original)
        :param stop_flag_func: optional external stop function
        """
        super().__init__(parent)
        self.ser = ser
        self._stop_flag_func = stop_flag_func
        self.name = "Arduino_Delete_SMS"

    def run(self):
        threading.current_thread().name = self.name
        ser = self.ser

        # -- EXACTLY like your original function --
        time.sleep(5)
        ser.flushInput()  # Clear any old input
        ser.write(b'DEL_ALL\n')
        print(">> Sent: DEL_ALL")

        response = []
        start = time.time()
        timeout = 3  # seconds

        print("<< Waiting for response...")
        while time.time() - start < timeout:
            if self._stop_flag_func and self._stop_flag_func():
                print("[ArduinoSMSDeleteWorker] Stop flag detected, aborting loop.")
                break
            if ser.in_waiting:
                line = ser.readline().decode(errors='ignore').strip()
                if line:
                    print("<<", line)
                    response.append(line)
            else:
                time.sleep(0.1)

        if not response:
            print("No response from Arduino after DEL_ALL.")

        self.delete_done.emit(response)

    def stop(self):
        print("[ArduinoSMSDeleteWorker] Stopping worker...")
        self._running = False
        self.wait()

# This class is for reset GSM module worker
class ArduinoGSMResetWorker(QThread):
    reset_done = pyqtSignal(list)  # Emits the list of response lines

    def __init__(self, ser, stop_flag_func=None, parent=None):
        """
        :param ser: an already-open serial.Serial object
        :param stop_flag_func: optional external stop function
        """
        super().__init__(parent)
        self.ser = ser
        self._stop_flag_func = stop_flag_func
        self.name = "Arduino_GSM_Reset"

    def run(self):
        threading.current_thread().name = self.name
        ser = self.ser

        response = []
        reset_success = False

        print(">> Starting GSM reset sequence...")
        ser.flushInput()  # Clear any old input
        attempt = 0
        max_attempts = 1  # Prevent endless loop

        while not reset_success and attempt < max_attempts:
            if self._stop_flag_func and self._stop_flag_func():
                print("[ArduinoGSMResetWorker] Stop flag detected, aborting.")
                break

            ser.write(b'GSM_RESET\n')
            attempt += 1
            print(f">> Sent: GSM_RESET (Attempt {attempt})")

            start = time.time()
            timeout = 3  # seconds to wait for the "done" response

            while time.time() - start < timeout:
                if ser.in_waiting:
                    line = ser.readline().decode(errors='ignore').strip()
                    if line:
                        print("<<", line)
                        response.append(line)
                        if "Reset GSM Module Done" in line:
                            print("** GSM reset success! **")
                            reset_success = True
                            break
                else:
                    time.sleep(0.1)

            if not reset_success:
                print(f"-- No success, will retry GSM_RESET...")

        if not reset_success:
            print("!! GSM reset failed after all attempts.")

        self.reset_done.emit(response)

    def stop(self):
        print("[ArduinoGSMResetWorker] Stopping worker...")
        if hasattr(self, "_running"):
            self._running = False
        self.wait()