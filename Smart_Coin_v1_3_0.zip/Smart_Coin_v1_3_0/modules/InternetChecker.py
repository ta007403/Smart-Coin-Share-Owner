import socket
from PyQt5.QtCore import QThread, pyqtSignal

class InternetChecker(QThread):
    internet_status = pyqtSignal(bool)

    def run(self):
        try:
            # Fast low-level check (no DNS)
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            self.internet_status.emit(True)
        except OSError:
            self.internet_status.emit(False)