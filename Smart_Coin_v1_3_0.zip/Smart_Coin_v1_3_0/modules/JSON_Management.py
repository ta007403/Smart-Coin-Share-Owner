import json
import os
from dotenv import load_dotenv

load_dotenv()

DATA_CONFIG_JSON_FILE = os.getenv("DATA_CONFIG_JSON_FILE")
if DATA_CONFIG_JSON_FILE is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

JSON_FILE = os.getenv("NFC_JSON_FILE")
if JSON_FILE is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

class MoneyDataManager:
    def __init__(self):
        self.config_file_path = DATA_CONFIG_JSON_FILE
        self.nfc_file_path = JSON_FILE
        self.data = self.load_json(self.config_file_path)
        self.NFC_data = self.load_json(self.nfc_file_path)

    def refresh_json_data(self):
        self.config_file_path = DATA_CONFIG_JSON_FILE
        self.nfc_file_path = JSON_FILE
        self.data = self.load_json(self.config_file_path)
        self.NFC_data = self.load_json(self.nfc_file_path)

    def load_json(self, file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def save_json(self, file_path, data):
        print("SAVING DATA! from JSON Management")
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def reload(self):
        self.data = self.load_json(self.config_file_path)

    def count_wallets_in_file(self, print_result=True):
        self.refresh_json_data()
        if isinstance(self.NFC_data, list):
            wallet_count = sum(1 for entry in self.NFC_data if 'wallet_id' in entry)
        else:
            wallet_count = 0
        
        wallet_count += 1 # Prevent off by one error

        if print_result:
            print(f"Number of NFC wallets: {wallet_count}")
        return wallet_count

    def set_amount_of_nfc_wallet(self, amount):
        self.refresh_json_data()
        self.data['configuration']['Amount of NFC Wallet'] = str(amount)
        self.save_json(self.config_file_path, self.data)

    def set_withdraw_enable(self, value):
        self.refresh_json_data()
        self.data['configuration']['Withdraw Enable'] = value
        self.save_json(self.config_file_path, self.data)

    def get_withdraw_enable(self):
        return self.data.get('configuration', {}).get('Withdraw Enable', 0)

    def set_bank_transfer_enable(self, value):
        self.refresh_json_data()
        self.data['configuration']['Bank Transfer Enable'] = value
        self.save_json(self.config_file_path, self.data)

    def get_bank_transfer_enable(self):
        return self.data.get('configuration', {}).get('Bank Transfer Enable', 0)

    def set_smart_coin_software_version(self, value):
        self.refresh_json_data()
        self.data['information']['Smart Coin Software Version'] = value
        self.save_json(self.config_file_path, self.data)

    def set_arduino_firmware_version(self, value):
        self.refresh_json_data()
        self.data['information']['Arduino GSM Version'] = value
        self.save_json(self.config_file_path, self.data)

    def get_beginning_banknote_100(self):
        return self.data.get('banknotes_in_the_cassette_at_the_beginning', {}).get('100', 0)
        
    def get_beginning_banknote_500(self):
        return self.data.get('banknotes_in_the_cassette_at_the_beginning', {}).get('500', 0)

    def get_beginning_banknote_1000(self):
        return self.data.get('banknotes_in_the_cassette_at_the_beginning', {}).get('1000', 0)

    # ----- Current banknotes in cassette -----
    def set_current_banknote_100(self, value):
        self.refresh_json_data()
        self.data['current banknotes in the cassette']['100'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_banknote_500(self, value):
        self.refresh_json_data()
        self.data['current banknotes in the cassette']['500'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_banknote_1000(self, value):
        self.refresh_json_data()
        self.data['current banknotes in the cassette']['1000'] = value
        self.save_json(self.config_file_path, self.data)

    # ----- Current banknotes in cassette -----
    def get_current_banknote_100(self):
        return self.data.get('current banknotes in the cassette', {}).get('100', 0)
    def get_current_banknote_500(self):
        return self.data.get('current banknotes in the cassette', {}).get('500', 0)
    def get_current_banknote_1000(self):
        return self.data.get('current banknotes in the cassette', {}).get('1000', 0)

    # ----- Current coins inside the box -----
    def set_current_coin_1(self, value):
        self.refresh_json_data()
        self.data['coins inside the box']['1'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_coin_2(self, value):
        self.refresh_json_data()
        self.data['coins inside the box']['2'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_coin_5(self, value):
        self.refresh_json_data()
        self.data['coins inside the box']['5'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_coin_10(self, value):
        self.refresh_json_data()
        self.data['coins inside the box']['10'] = value
        self.save_json(self.config_file_path, self.data)

    # ----- Current coins inside the box -----
    def get_current_coin_1(self):
        return self.data.get('coins inside the box', {}).get('1', 0)
    def get_current_coin_2(self):
        return self.data.get('coins inside the box', {}).get('2', 0)
    def get_current_coin_5(self):
        return self.data.get('coins inside the box', {}).get('5', 0)
    def get_current_coin_10(self):
        return self.data.get('coins inside the box', {}).get('10', 0)

    # ----- Current banknotes inside the box -----
    def set_current_note_20(self, value):
        self.refresh_json_data()
        self.data['banknotes inside the box']['20'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_note_50(self, value):
        self.refresh_json_data()
        self.data['banknotes inside the box']['50'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_note_100(self, value):
        self.refresh_json_data()
        self.data['banknotes inside the box']['100'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_note_500(self, value):
        self.refresh_json_data()
        self.data['banknotes inside the box']['500'] = value
        self.save_json(self.config_file_path, self.data)
    def set_current_note_1000(self, value):
        self.refresh_json_data()
        self.data['banknotes inside the box']['1000'] = value
        self.save_json(self.config_file_path, self.data)

    # ----- Current banknotes inside the box -----
    def get_current_note_20(self):
        return self.data.get('banknotes inside the box', {}).get('20', 0)
    def get_current_note_50(self):
        return self.data.get('banknotes inside the box', {}).get('50', 0)
    def get_current_note_100(self):
        return self.data.get('banknotes inside the box', {}).get('100', 0)
    def get_current_note_500(self):
        return self.data.get('banknotes inside the box', {}).get('500', 0)
    def get_current_note_1000(self):
        return self.data.get('banknotes inside the box', {}).get('1000', 0)

    # ----- Banknotes at the beginning (not allow to chaange this number by user) -----
    #def set_beginning_banknote_100(self, value):
    #    self.data['banknotes_in_the_cassette_at_the_beginning']['100'] = value
    #    self.save_json(self.config_file_path, self.data)
    #def set_beginning_banknote_500(self, value):
    #    self.data['banknotes_in_the_cassette_at_the_beginning']['500'] = value
    #    self.save_json(self.config_file_path, self.data)
    #def set_beginning_banknote_1000(self, value):
    #    self.data['banknotes_in_the_cassette_at_the_beginning']['1000'] = value
    #    self.save_json(self.config_file_path, self.data)

    # ----- Money totals but this is use in Server_API.py for update summary detail -----
    def set_total_coins_value(self, value):
        self.refresh_json_data()
        self.data['total coins value in the box'] = value
        self.save_json(self.config_file_path, self.data)
    def set_total_banknotes_value(self, value):
        self.refresh_json_data()
        self.data['total banknotes value in the box'] = value
        self.save_json(self.config_file_path, self.data)
    def set_total_physical_money_value(self, value):
        self.refresh_json_data()
        self.data['total physical money value in the box'] = value
        self.save_json(self.config_file_path, self.data)

    # ----- Money totals summary -----
    def set_customer_transferred_amount(self, value):
        self.refresh_json_data()
        self.data['customer transferred amount'] = value
        self.save_json(self.config_file_path, self.data)
    def set_total_withdraw_amount(self, value):
        self.refresh_json_data()
        self.data['total Withdraw Amount'] = value
        self.save_json(self.config_file_path, self.data)

    def get_customer_transferred_amount(self):
        return self.data.get('customer transferred amount', 0)

    def get_total_withdraw_amount(self):
        return self.data.get('total Withdraw Amount', 0)