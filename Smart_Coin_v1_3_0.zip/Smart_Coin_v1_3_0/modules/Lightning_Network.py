from PyQt5.QtCore import QObject, QThread, pyqtSignal
import requests
import threading
import websocket
import json
import os
from dotenv import load_dotenv
import time
import re

load_dotenv()

LNBITS_MAIN_URL = os.getenv("LNBITS_MAIN_URL")
if LNBITS_MAIN_URL is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

LNBITS_API_INVOICE_KEY = os.getenv("LNBITS_API_INVOICE_KEY")
if LNBITS_API_INVOICE_KEY is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

LNBITS_API_ADMIN_KEY = os.getenv("LNBITS_API_ADMIN_KEY")
if LNBITS_API_ADMIN_KEY is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

MACHINE_ID = os.getenv("MACHINE_ID")
if MACHINE_ID is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")
    
SMARTCOIN_BALANCE_API_URL = os.getenv("SMARTCOIN_BALANCE_API_URL")
if SMARTCOIN_BALANCE_API_URL is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

SMARTCOIN_DEVICE_ID = os.getenv("SMARTCOIN_DEVICE_ID")
if SMARTCOIN_DEVICE_ID is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

SMARTCOIN_DEVICE_SECRET = os.getenv("SMARTCOIN_DEVICE_SECRET")
if SMARTCOIN_DEVICE_SECRET is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")    

LNBITS_API_BASE_URL = f"https://{LNBITS_MAIN_URL}"
LNBITS_API_PAYMENT_URL = f"{LNBITS_API_BASE_URL}/api/v1/payments"
WEB_SOCKET_URL = f"wss://{LNBITS_MAIN_URL}/api/v1/ws/{LNBITS_API_ADMIN_KEY}"

# This function is use for check LN wallet address from internet

#https://{domain}/.well-known/lnurlp/{name}
#https://walletofsatoshi.com/.well-known/lnurlp/lyricalweather78

#"callback": "https://livingroomofsatoshi.com/api/v1/lnurl/payreq/8f6c1e60-2767-47e6-83c1-af4d8eac4634",
#"maxSendable": 100000000000,
#"minSendable": 1000,
#"metadata": "[[\"text/plain\",\"Pay to Wallet of Satoshi user: lyricalweather78\"],[\"text/identifier\",\"lyricalweather78@walletofsatoshi.com\"]]",
#"commentAllowed": 255,
#"tag": "payRequest",
#"allowsNostr": true,
#"nostrPubkey": "be1d89794bf92de5dd64c1e60f6a2c70c140abac9932418fee30c5c637fe9479"
class LNURLCheckerWorker(QThread):
    finished = pyqtSignal(object)   # Will emit result (dict or str or whatever)

    def __init__(self, lightning_address):
        super().__init__()
        self.lightning_address = lightning_address
        self.name = "Lightning Network"

    def run(self):
        # This will run in background
        threading.current_thread().name = self.name
        result = self.check_lnurl(self.lightning_address)
        self.finished.emit(result)

    def check_lnurl(self, lightning_address, retries=1, delay=2):
        last_error = None

        # 1. If it's already a URL, just try it
        if isinstance(lightning_address, str) and (lightning_address.startswith("http://") or lightning_address.startswith("https://")):
            lnurl_candidates = [lightning_address]
        # 2. If it's bech32 LNURL, decode and try as URL
        elif isinstance(lightning_address, str) and re.match(r"^lnurl[a-z0-9]+$", lightning_address.lower()):
            try:
                lnurl_url = parse_lnurl(lightning_address)  # This function should decode LNURL bech32 to a URL
                lnurl_candidates = [lnurl_url]
            except Exception as e:
                return {"ok": False, "error": f"Failed to decode bech32 LNURL: {e}"}
        # 3. Lightning address format
        elif isinstance(lightning_address, str) and "@" in lightning_address:
            try:
                name, domain = lightning_address.split("@", 1)
            except Exception as e:
                return {"ok": False, "error": f"Invalid lightning address: {e}"}
            lnurl_candidates = [
                f"https://{domain}/.well-known/lnurlp/{name}",
                f"https://{domain}/lnurlp/{name}",
            ]
        else:
            return {"ok": False, "error": "Unknown LNURL or address format"}

        # Try each candidate endpoint
        for lnurlp_url in lnurl_candidates:
            for attempt in range(retries + 1):
                try:
                    r1 = requests.get(lnurlp_url, timeout=5)
                    if r1.status_code != 200:
                        last_error = f"Could not resolve ({lnurlp_url}) (HTTP {r1.status_code}): {r1.text}"
                        print(f"[LNURL] Attempt {attempt+1}: {last_error}")
                        if attempt < retries:
                            time.sleep(delay)
                        continue
                    data = r1.json()
                    callback = data.get("callback")
                    if not callback:
                        last_error = f"Missing callback in LNURLp response for {lnurlp_url}"
                        print(f"[LNURL] Attempt {attempt+1}: {last_error}")
                        if attempt < retries:
                            time.sleep(delay)
                        continue
                    print(f"[LNURL] Success for {lnurlp_url}")
                    return {"ok": True, "data": data, "lnurlp_url": lnurlp_url}
                except Exception as e:
                    last_error = f"Exception for {lnurlp_url}: {e}"
                    print(f"[LNURL] Fetch error (attempt {attempt+1}): {last_error}")
                    if attempt < retries:
                        time.sleep(delay)
        return {"ok": False, "error": last_error or "Unknown LNURL error"}

# This class is use for withdrawal page
# The worker will wait for customer transfer sat
class LNbitsWebSocketWorker(QThread):
    payment_received = pyqtSignal(dict)
    payment_timeout = pyqtSignal()
    payment_error = pyqtSignal(str)

    def __init__(self, payment_hash, parent=None):
        super().__init__(parent)
        self.payment_hash = payment_hash
        self._stop = False
        self.name = "LN Payment Polling"
        self.poll_interval = 2.0
        self.timeout_seconds = 300

    def check_payment(self):
        url = f"{LNBITS_API_BASE_URL}/api/v1/payments/{self.payment_hash}"

        headers = {
            "X-Api-Key": LNBITS_API_INVOICE_KEY
        }

        response = requests.get(url, headers=headers, timeout=10)

        if response.status_code != 200:
            raise Exception(f"Status check failed: {response.status_code} | {response.text}")

        return response.json().get("paid", False), response.json()

    def run(self):
        threading.current_thread().name = self.name
        print("[Polling] Started.")
        print(f"[Polling] payment_hash = {self.payment_hash}")
        print(f"[Polling] base_url = {LNBITS_API_BASE_URL}")

        start_time = time.time()

        while not self._stop:
            try:
                paid, raw_data = self.check_payment()
                print(f"[Polling] paid = {paid}")

                if paid:
                    print("[Polling] Payment received.")
                    self.payment_received.emit(raw_data)
                    break

                if time.time() - start_time > self.timeout_seconds:
                    print("[Polling] Timeout reached.")
                    self.payment_timeout.emit()
                    break

            except Exception as e:
                print("[Polling] Error checking payment:", e)
                self.payment_error.emit(str(e))

            time.sleep(self.poll_interval)

        print("[Polling] Exiting polling loop.")

    def stop(self):
        self._stop = True
        print("[Polling] Stop requested.")

# This class is use for create invoice from LNbits
# The worker will get invoice with amount for generate QR code later
# This is get invoice from LNbits for withdrawal request
class LNbitsInvoiceWorker(QThread):
    invoice_ready = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, amount_sats, memo="Invoice from LNbits", expiry=None, unit="sat", webhook=None, internal=False, parent=None):
        super().__init__(parent)
        self.amount_sats = amount_sats
        self.memo = memo
        self.expiry = expiry
        self.unit = unit
        self.webhook = webhook
        self.internal = internal
        self.invoice = None
        self.exception = None
        self.name = "LN Invoice"

    def run(self):
        threading.current_thread().name = self.name
        global LNBITS_API_INVOICE_KEY
        global LNBITS_API_PAYMENT_URL

        try:
            headers = {
                "X-Api-Key": LNBITS_API_INVOICE_KEY,
                "Content-type": "application/json"
            }

            payload = {
                "out": False,
                "amount": self.amount_sats,
                "memo": self.memo,
                "unit": self.unit,
                "internal": self.internal
            }

            if self.expiry is not None:
                payload["expiry"] = self.expiry
            if self.webhook is not None:
                payload["webhook"] = self.webhook

            response = requests.post(LNBITS_API_PAYMENT_URL, headers=headers, json=payload)

            if response.status_code != 201:
                raise Exception(f"Could not create LNbits invoice: {response.text}")

            data = response.json()
            print("[DEBUG] LNbits invoice response:", data)

            self.invoice = data
            self.invoice_ready.emit(data)

        except Exception as e:
            self.exception = e
            self.error.emit(str(e))

# This class is use for check balance in Smart Coin system
# v1.2.1+: goes through smartcoin-thailand.com (device secret auth).
# The machine no longer reads LNbits /api/v1/wallet directly and holds
# no read key for it. Response is sats; we emit msat so main.py's
# existing  int(balance / 1000)  keeps working unchanged.
class LNbitsBalanceWorker(QThread):
    balance_ready = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.url = SMARTCOIN_BALANCE_API_URL
        self.device_id = SMARTCOIN_DEVICE_ID
        self.device_secret = SMARTCOIN_DEVICE_SECRET
        self.name = "LN Balance"

    def run(self, retries=1, delay=2):
        threading.current_thread().name = self.name
        headers = {
            "X-Device-Id": self.device_id,
            "X-Device-Secret": self.device_secret,
            "Accept": "application/json",
        }
        last_error = None

        print(f"[Debug] POST {self.url}")
        print(f"[Debug] device_id = {self.device_id}")
        # NOTE: never print the secret (old version leaked key prefix to logs)

        for attempt in range(retries + 1):
            try:
                response = requests.post(self.url, headers=headers, timeout=10)

                if response.status_code == 403:
                    # Wrong/revoked secret — retrying won't help
                    self.error.emit(
                        "Balance API 403: device not authorized. "
                        "Check SMARTCOIN_DEVICE_ID / SMARTCOIN_DEVICE_SECRET in .env"
                    )
                    return

                response.raise_for_status()
                data = response.json()
                balance_sats = data.get("balance_sats", None)

                if balance_sats is not None:
                    balance_msat = int(balance_sats) * 1000  # keep old msat contract
                    print(f"[Debug] balance = {balance_sats:,} sat")
                    self.balance_ready.emit(balance_msat)
                    return  # Success! Exit the function.
                else:
                    last_error = "No balance_sats returned from balance API."
                    print(f"[Balance] Attempt {attempt+1}: {last_error}")

            except Exception as e:
                last_error = f"Error checking machine balance: {e}"
                print(f"[Balance] Fetch error (attempt {attempt+1}): {last_error}")

            if attempt < retries:
                time.sleep(delay)

        # If we reach here, all attempts failed
        self.error.emit(last_error or "Unknown error checking machine balance.")

# This class is use for create invoice from user wallet
# The worker will get invoice with amount for pay sat from LNbits to customer's wallet
# This is get invoice from LNbits for deposit request
class CustomerInvoiceWorker(QThread):
    invoice_ready = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, lightning_address, amount_sats, parent=None):
        super().__init__(parent)
        self.lightning_address = lightning_address
        self.amount_sats = amount_sats
        self.name = "LN Customer Invoice"

    def run(self, retries=1, delay=2):
        """
        Try both possible LNURLp endpoints.
        """
        threading.current_thread().name = self.name

        try:
            lnurl_candidates = []

            # If direct URL is provided (for future extensibility)
            if isinstance(self.lightning_address, str) and (
                self.lightning_address.startswith("http://") or self.lightning_address.startswith("https://")
            ):
                lnurl_candidates = [self.lightning_address]
            # If it's a bech32 LNURL, you should decode it to get the real URL (see previous messages)
            elif re.match(r"^lnurl[a-z0-9]+$", self.lightning_address.lower()):
                try:
                    lnurl_url = parse_lnurl(self.lightning_address)  # You must provide this function!
                    lnurl_candidates = [lnurl_url]
                except Exception as e:
                    self.error.emit(f"Failed to decode bech32 LNURL: {e}")
                    return
            # Lightning Address
            elif "@" in self.lightning_address:
                try:
                    name, domain = self.lightning_address.split("@", 1)
                except Exception as e:
                    self.error.emit(f"Invalid lightning address: {e}")
                    return
                lnurl_candidates = [
                    f"https://{domain}/.well-known/lnurlp/{name}",
                    f"https://{domain}/lnurlp/{name}",
                ]
            else:
                self.error.emit("Unknown LNURL or address format")
                return

            # --- LNURLP Info Fetch with Retries ---
            last_error = None
            callback = None
            for lnurlp_url in lnurl_candidates:
                for attempt in range(retries + 1):
                    try:
                        r1 = requests.get(lnurlp_url, timeout=5)
                        if r1.status_code == 200:
                            data = r1.json()
                            callback = data.get("callback")
                            if not callback:
                                last_error = "Missing callback in LNURLp response"
                                print(f"[LNURL] Attempt {attempt+1}: {last_error}")
                            else:
                                break  # Success, exit inner retry loop
                        else:
                            last_error = f"Could not resolve LNURLp ({lnurlp_url}) (HTTP {r1.status_code}): {r1.text}"
                            print(f"[LNURL] Attempt {attempt+1}: {last_error}")
                    except Exception as e:
                        last_error = f"Exception fetching LNURLp: {e}"
                        print(f"[LNURL] Attempt {attempt+1}: {last_error}")
                    if attempt < retries:
                        time.sleep(delay)
                if callback:
                    break  # Success with this candidate
            else:
                self.error.emit(last_error or "Failed to fetch LNURLp info")
                return

            # --- Amount Check ---
            if not isinstance(self.amount_sats, int) or self.amount_sats < 1:
                self.error.emit("Amount must be at least 1 satoshi.")
                return

            # --- Invoice Fetch with Retries ---
            last_error = None
            for attempt in range(retries + 1):
                try:
                    r2 = requests.get(callback, params={"amount": self.amount_sats * 1000}, timeout=5)
                    if r2.status_code == 200:
                        invoice_data = r2.json()
                        print("[DEBUG] LNURL callback response:", invoice_data)
                        if "pr" in invoice_data:
                            self.invoice_ready.emit(invoice_data["pr"])
                            return  # Success!
                        else:
                            last_error = f"Missing 'pr' in invoice response: {invoice_data}"
                            print(f"[LNURL] Attempt {attempt+1}: {last_error}")
                    else:
                        last_error = f"Could not get invoice (HTTP {r2.status_code}): {r2.text}"
                        print(f"[LNURL] Attempt {attempt+1}: {last_error}")
                except Exception as e:
                    last_error = f"Exception: {e}"
                    print(f"[LNURL] Invoice fetch error (attempt {attempt+1}): {last_error}")
                if attempt < retries:
                    time.sleep(delay)
            else:
                self.error.emit(last_error or "Failed to fetch invoice from LNURL callback")
                return

        except Exception as e:
            self.error.emit(f"LNURL worker error: {e}")

# This class is use for pay sat to invoice
class LNbitsPayWorker(QThread):
    payment_success = pyqtSignal(str)  # emits payment_hash
    payment_error = pyqtSignal(str)    # emits error message

    def __init__(self, bolt11_invoice, parent=None):
        super().__init__(parent)
        self.api_key = LNBITS_API_ADMIN_KEY
        self.api_url = LNBITS_API_PAYMENT_URL
        self.bolt11_invoice = bolt11_invoice
        self.name = "LN Pay"

    def run(self):
        threading.current_thread().name = self.name
        result = self.pay_invoice_with_retry(
            self.bolt11_invoice,
            retries=2,       # total attempts = retries + 1
            delay=2          # seconds between retries
        )

        if result["ok"]:
            self.payment_success.emit(result["payment_hash"])
        else:
            self.payment_error.emit(result["error"])

    def pay_invoice_with_retry(self, bolt11, retries=2, delay=2):
        headers = {
            "X-Api-Key": self.api_key,
            "Content-type": "application/json"
        }

        data = {
            "out": True,
            "bolt11": bolt11,
            "extra": {
                "memo": f"Bitcoin Lightning Topup | Machine:{MACHINE_ID}",
                "machine_id": MACHINE_ID,
                "source": "topup_machine"
            }
        }

        last_error = None

        for attempt in range(retries + 1):
            try:
                print(f"[LNbits] Payment attempt {attempt+1}")

                response = requests.post(
                    self.api_url,
                    json=data,
                    headers=headers,
                    timeout=10   # IMPORTANT: prevent hanging forever
                )

                # SUCCESS
                if response.status_code == 201:
                    payment_hash = response.json().get("payment_hash")
                    print(f"[LNbits] Payment success")
                    return {
                        "ok": True,
                        "payment_hash": payment_hash or "No hash found"
                    }

                # SERVER ERROR (retryable)
                elif 500 <= response.status_code < 600:
                    last_error = f"Server error {response.status_code}: {response.text}"
                    print(f"[LNbits] Retryable error: {last_error}")

                # CLIENT ERROR (do NOT retry)
                else:
                    error_msg = f"Failed ({response.status_code}): {response.text}"
                    print(f"[LNbits] Non-retryable error: {error_msg}")
                    return {
                        "ok": False,
                        "error": error_msg
                    }

            except requests.exceptions.Timeout:
                last_error = "Timeout while contacting LNbits"
                print(f"[LNbits] Timeout on attempt {attempt+1}")

            except requests.exceptions.ConnectionError as e:
                last_error = f"Connection error: {e}"
                print(f"[LNbits] Connection error on attempt {attempt+1}")

            except Exception as e:
                # Unknown error — retryable but logged
                last_error = f"Exception: {e}"
                print(f"[LNbits] Exception on attempt {attempt+1}: {e}")

            # Retry logic
            if attempt < retries:
                print(f"[LNbits] Waiting {delay} seconds before retry...")
                time.sleep(delay)
            else:
                print("[LNbits] All retries exhausted")

        return {
            "ok": False,
            "error": last_error or "Unknown payment error"
        }
        
        
# If you want to run directly for testing:
# if __name__ == "__main__":
#     worker = LNbitsInvoiceWorker(amount_sats=1234, memo="Invoice via worker")
#     worker.start()
#     worker.join()  # Wait for background worker to finish

#     if worker.exception:
#         print("Error:", worker.exception)
#     else:
#         print("LNbits Invoice:", worker.invoice)