from PyQt5.QtCore import QThread, pyqtSignal
from dotenv import load_dotenv
from datetime import datetime
import requests
import threading
import json
import os
import time

load_dotenv()

JSON_FILE = os.getenv("NFC_JSON_FILE")
if JSON_FILE is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

TMP_FILE = os.getenv("NFC_TMP_FILE")
if TMP_FILE is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

DATA_CONFIG_JSON_FILE = os.getenv("DATA_CONFIG_JSON_FILE")
if DATA_CONFIG_JSON_FILE is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

LNBITS_API_ADMIN_KEY = os.getenv("LNBITS_API_ADMIN_KEY")
if LNBITS_API_ADMIN_KEY is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

MACHINE_ID = os.getenv("MACHINE_ID")
if MACHINE_ID is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

MASTER_KEY = os.getenv("MASTER_KEY")
if MASTER_KEY is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

API_URL = os.getenv("NFC_BALANCE_API_URL")
if API_URL is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

LNBITS_MAIN_URL = os.getenv("LNBITS_MAIN_URL")
if LNBITS_MAIN_URL is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

LNBITS_API_BASE_URL = f"https://{LNBITS_MAIN_URL}"

# This class use for check NFC registered with Smart Coin or not
class NFCReader:
    @staticmethod
    def NFC_Check_Register(UID, retries=2, delay=1):
        headers = {"X-WM-KEY": MASTER_KEY}
        payload = {"uid": UID.strip().upper()}

        last_error = None

        for attempt in range(retries + 1):
            try:
                print(f"[NFC] Register check attempt {attempt+1}")

                r = requests.post(
                    API_URL,
                    headers=headers,
                    json=payload,
                    timeout=5
                )

                if r.status_code == 200:
                    return True

                # Retry only on server error
                if 500 <= r.status_code < 600:
                    last_error = f"Server error {r.status_code}"
                    print("[NFC] Retryable:", last_error)
                else:
                    # 4xx → do not retry
                    print("[NFC] Non-retryable:", r.status_code)
                    return False

            except requests.exceptions.RequestException as e:
                last_error = str(e)
                print(f"[NFC] Network error on attempt {attempt+1}: {e}")

            if attempt < retries:
                time.sleep(delay)
            else:
                print("[NFC] All retries exhausted")

        return False

    @staticmethod
    def NFC_Get_Wallet_Address(uid, retries=2, delay=1):
        headers = {
            "X-WM-KEY": MASTER_KEY,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        payload = {
            "uid": uid.strip().upper()
        }

        last_error = None

        for attempt in range(retries + 1):
            try:
                print(f"[NFC] Wallet fetch attempt {attempt+1}")

                response = requests.post(
                    API_URL,
                    headers=headers,
                    json=payload,
                    timeout=5
                )

                if response.status_code == 200:

                    if "application/json" not in response.headers.get("Content-Type", ""):
                        last_error = "Non-JSON response"
                        print("[NFC]", last_error)

                    else:
                        try:
                            data = response.json()
                        except ValueError:
                            last_error = "Invalid JSON"
                            print("[NFC]", last_error)
                            continue

                        wallet_address = data.get("wallet_address")

                        if wallet_address:
                            return wallet_address
                        else:
                            last_error = "wallet_address missing"
                            print("[NFC]", last_error)

                elif 500 <= response.status_code < 600:
                    last_error = f"Server error {response.status_code}"
                    print("[NFC] Retryable:", last_error)

                else:
                    # 4xx → probably invalid UID
                    print("[NFC] Non-retryable:", response.status_code)
                    return None

            except requests.exceptions.RequestException as e:
                last_error = str(e)
                print(f"[NFC] Network error on attempt {attempt+1}: {e}")

            if attempt < retries:
                time.sleep(delay)
            else:
                print("[NFC] All retries exhausted")

        return None

# This class use for refill sat to NFC
class RefillCardWorker(QThread):
    refill_success = pyqtSignal(str, str, dict)
    error = pyqtSignal(str)

    def __init__(self, wallet_address, sat_amount, parent=None):
        super().__init__(parent)
        self.wallet_address = wallet_address
        self.sat_amount = sat_amount
        self.name = "NFC Refill (LN Address)"
        self.sender_wallet_key = LNBITS_API_ADMIN_KEY
        self.lnbits_base = LNBITS_API_BASE_URL

    def run(self):
        threading.current_thread().name = self.name

        try:
            print("\n================ REFILL START ================")

            # STEP 1 — LNURL Metadata
            lnurl_data = self.fetch_lnurl_metadata(retries=2)
            if not lnurl_data["ok"]:
                self.error.emit(lnurl_data["error"])
                return

            callback = lnurl_data["callback"]

            # STEP 2 — Request Invoice
            invoice_data = self.request_invoice(callback, retries=2)
            if not invoice_data["ok"]:
                self.error.emit(invoice_data["error"])
                return

            invoice = invoice_data["invoice"]

            # STEP 3 — Pay Invoice
            payment_data = self.pay_invoice(invoice, retries=2)
            if not payment_data["ok"]:
                self.error.emit(payment_data["error"])
                return

            print("================ REFILL SUCCESS ==============\n")

            self.refill_success.emit(
                invoice,
                payment_data["payment_hash"],
                payment_data["raw"]
            )

        except Exception as e:
            print("🔥 Exception inside refill worker:", e)
            self.error.emit(f"Exception: {e}")

    def fetch_lnurl_metadata(self, retries=2, delay=1):
        #username, domain = self.wallet_address.split("@")
        try:
            username, domain = self.wallet_address.split("@", 1)
        except ValueError:
            return {"ok": False, "error": "Invalid Lightning address format"}

        lnurl_endpoint = f"https://{domain}/.well-known/lnurlp/{username}"

        last_error = None

        for attempt in range(retries + 1):
            try:
                print(f"[LNURL] Metadata attempt {attempt+1}")

                r = requests.get(lnurl_endpoint, timeout=8)

                if r.status_code == 200:
                    try:
                        data = r.json()
                    except ValueError:
                        last_error = "Invalid JSON response"
                        continue
                    callback = data.get("callback")
                    if callback:
                        return {"ok": True, "callback": callback}
                    last_error = "No callback in LNURL response"

                elif 500 <= r.status_code < 600:
                    last_error = f"Server error {r.status_code}"

                else:
                    return {"ok": False, "error": f"LNURL failed: {r.status_code}"}

            except requests.exceptions.RequestException as e:
                last_error = str(e)

            if attempt < retries:
                time.sleep(delay)

        return {"ok": False, "error": last_error or "LNURL metadata error"}

    def request_invoice(self, callback, retries=2, delay=1):
        last_error = None

        for attempt in range(retries + 1):
            try:
                print(f"[LNURL] Invoice attempt {attempt+1}")

                r = requests.get(
                    callback,
                    params={"amount": self.sat_amount * 1000},
                    timeout=8
                )

                if r.status_code == 200:
                    try:
                        data = r.json()
                    except ValueError:
                        last_error = "Invalid JSON response"
                        continue
                    invoice = data.get("pr")
                    if invoice:
                        return {"ok": True, "invoice": invoice}
                    last_error = "No invoice returned"

                elif 500 <= r.status_code < 600:
                    last_error = f"Server error {r.status_code}"

                else:
                    return {"ok": False, "error": f"Invoice request failed: {r.status_code}"}

            except requests.exceptions.RequestException as e:
                last_error = str(e)

            if attempt < retries:
                time.sleep(delay)

        return {"ok": False, "error": last_error or "Invoice request error"}

    def pay_invoice(self, invoice, retries=2, delay=2):
        pay_url = f"{self.lnbits_base}/api/v1/payments"

        headers = {
            "X-Api-Key": self.sender_wallet_key,
            "Content-Type": "application/json"
        }

        payload = {
            "out": True,
            "bolt11": invoice
        }

        last_error = None

        for attempt in range(retries + 1):
            try:
                print(f"[LNbits] Payment attempt {attempt+1}")

                r = requests.post(
                    pay_url,
                    headers=headers,
                    json=payload,
                    timeout=10
                )

                if r.status_code in [200, 201]:
                    try:
                        data = r.json()
                    except ValueError:
                        last_error = "Invalid JSON response"
                        continue
                    return {
                        "ok": True,
                        "payment_hash": data.get("payment_hash", ""),
                        "raw": data
                    }

                elif 500 <= r.status_code < 600:
                    last_error = f"Server error {r.status_code}"

                else:
                    # DO NOT RETRY 4xx
                    return {"ok": False, "error": f"Payment failed: {r.text}"}

            except requests.exceptions.RequestException as e:
                last_error = str(e)

            if attempt < retries:
                time.sleep(delay)

        return {"ok": False, "error": last_error or "Payment retry exhausted"}

# This class use for check NFC balance
class NFCBalanceWorker(QThread):
    balance_ready = pyqtSignal(int)
    error = pyqtSignal(str)

    def __init__(self, nfc_uid, parent=None):
        super().__init__(parent)
        self.nfc_uid = nfc_uid
        self.name = "NFC Balance (API)"

    def run(self):
        threading.current_thread().name = self.name

        result = self.fetch_balance(retries=2)

        if result["ok"]:
            self.balance_ready.emit(result["balance"])
        else:
            self.error.emit(result["error"])

    def fetch_balance(self, retries=2, delay=1):
        headers = {
            "X-WM-KEY": MASTER_KEY,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        payload = {"uid": self.nfc_uid}
        last_error = None

        for attempt in range(retries + 1):
            try:
                print(f"[Balance] Attempt {attempt+1}")

                r = requests.post(
                    API_URL,
                    headers=headers,
                    json=payload,
                    timeout=8
                )

                if r.status_code == 200:
                    try:
                        data = r.json()
                    except ValueError:
                        last_error = "Invalid JSON response"
                        continue
                    balance = data.get("balance_sats")
                    if balance is not None:
                        return {"ok": True, "balance": int(balance)}
                    last_error = "Balance missing"

                elif 500 <= r.status_code < 600:
                    last_error = f"Server error {r.status_code}"

                else:
                    return {"ok": False, "error": f"API error {r.status_code}"}

            except requests.exceptions.RequestException as e:
                last_error = str(e)

            if attempt < retries:
                time.sleep(delay)

        return {"ok": False, "error": last_error or "Balance request failed"}


# This function use for sync NFC database (This function will not use anymore)
def sync_card_database():
    # === Load Configuration from data.json ===
    force_full_sync = False
    config_data = {}
    if os.path.exists(DATA_CONFIG_JSON_FILE):
        with open(DATA_CONFIG_JSON_FILE, "r", encoding="utf-8") as config_file:
            config_data = json.load(config_file)
            if isinstance(config_data, list) and len(config_data) > 0:
                config_data = config_data[0]
            force_full_sync = config_data.get("configuration", {}).get("Need to Update NFC Database", "No") == "Yes"
            print(f"Raw config value: '' → force_full_sync = {force_full_sync}")

    # === Load Existing Wallet Data and Last Sync Time ===
    wallets = []
    last_sync_time = "1970-01-01T00:00:00"
    sync_count = 0

    if os.path.exists(JSON_FILE):
        with open(JSON_FILE, "r", encoding="utf-8") as f:
            existing_data = json.load(f)
            last_meta = existing_data[0].get("Last_Time_Sync", {})
            if not force_full_sync:
                last_sync_time = last_meta.get("ISO", last_sync_time)
            wallets = existing_data[1:]  # skip metadata
            sync_count = int(last_meta.get("Sync Count Since Start Up", 0))

    # === Step 1: Fetch New Updates from API ===
    params = {}
    if not force_full_sync:
        params["since"] = last_sync_time

    # Put the API key in the header instead
    headers = {
        "X-API-Key": API_KEY
    }

    try:
        print(f"Fetching updates since {last_sync_time}..." if not force_full_sync else "Performing full resync of wallet database...")
        response = requests.get(API_URL, params=params, headers=headers)
        response.raise_for_status()
        new_data = response.json()

        if new_data:
            if force_full_sync:
                wallets = new_data
            else:
                uid_set = {w['uid'] for w in wallets}
                new_wallets = [w for w in new_data if w['uid'] not in uid_set]
                wallets.extend(new_wallets)

            # === Step 2: Prepare Metadata Header ===
            now = datetime.now()
            meta = {
                "Last_Time_Sync": {
                    "Date": now.strftime("%d/%m/%Y"),
                    "Times": f"{now.strftime('%H:%M')}",
                    "Sync Count Since Start Up": str(sync_count + 1),
                    "ISO": now.isoformat()
                }
            }

            # === Step 3: Write to Temp File, Then Atomically Replace ===
            with open(TMP_FILE, "w", encoding="utf-8") as f:
                json.dump([meta] + wallets, f, indent=2, ensure_ascii=False)

            os.replace(TMP_FILE, JSON_FILE)

            print(f"{len(new_data)} wallet(s) synced." if force_full_sync else f"{len(new_wallets)} new wallet added.")
            print(f"Total wallets: {len(wallets)}")

            # === Step 4: Update config to reset full sync flag ===
            if force_full_sync:
                config_data.setdefault("configuration", {})["Need to Update NFC Database"] = "No"
                with open(DATA_CONFIG_JSON_FILE, "w", encoding="utf-8") as cfg:
                    json.dump(config_data, cfg, indent=2, ensure_ascii=False)
                print("Configuration updated: 'Need to Update NFC Database' set to 'No'")
                print("Saved config to:", DATA_CONFIG_JSON_FILE)
                
                with open(DATA_CONFIG_JSON_FILE, "r", encoding="utf-8") as f:
                    verify = json.load(f)
                    print("After write:", verify.get("configuration"))
        else:
            print("No updates. Wallet list is up to date.")

    except requests.RequestException as e:
        print("Failed to fetch data from API.")
        print("Error:", e)
    except Exception as e:
        print("Failed to process or write data.")
        print("Error:", e)