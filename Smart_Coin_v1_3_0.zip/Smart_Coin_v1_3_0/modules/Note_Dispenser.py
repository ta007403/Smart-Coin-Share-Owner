from PyQt5.QtCore import QObject, pyqtSignal, QThread
import serial
import time
import threading

def calc_checksum(cmd_bytes):
    """Simple checksum: sum of all bytes, keep lowest 8 bits."""
    return sum(cmd_bytes) & 0xFF

class DispenserWorker(QThread):
    def __init__(self, name, device, note_value):
        super().__init__()
        self.name = name
        self.device = device
        self.note_value = note_value
        self.serial_port = serial.Serial(
            device,
            baudrate=9600,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_EVEN,
            stopbits=serial.STOPBITS_ONE,
            timeout=1
        )
        self._running = True

    def send_command(self, cmd_bytes):
        """Send raw command bytes to dispenser."""
        self.serial_port.write(bytes(cmd_bytes))
        print(f"{self.name} sent: {' '.join(f'0x{b:02X}' for b in cmd_bytes)}")

    def dispense(self, count):
        """Dispense specified number of notes in one command."""
        # Command structure: 01 10 00 10 <count> <checksum>
        cmd = [0x01, 0x10, 0x00, 0x10, count]
        checksum = calc_checksum(cmd)
        cmd.append(checksum)
        self.send_command(cmd)
        print(f"{self.name} dispensing {count} of {self.note_value} note(s)")
        time.sleep(0.5)

    def reset(self):
        """Send reset command to dispenser."""
        # Command structure: 01 10 00 12 00 <checksum>
        cmd = [0x01, 0x10, 0x00, 0x12, 0x00]
        checksum = calc_checksum(cmd)
        cmd.append(checksum)
        self.send_command(cmd)
        print(f"{self.name} RESET sent")
        time.sleep(0.5)

    def run(self):
        while self._running:
            # Idle loop; you can add event/queue for jobs
            time.sleep(0.1)

    def stop(self):
        self._running = False
        self.serial_port.close()

# Instantiate workers
#worker_100 = DispenserWorker('Dispenser100', '/dev/ttyUSB5', 100)
#worker_500 = DispenserWorker('Dispenser500', '/dev/ttyUSB6', 500)
#worker_1000 = DispenserWorker('Dispenser1000', '/dev/ttyUSB7', 1000)

# Start them
#worker_100.start()
#worker_500.start()
#worker_1000.start()

# Example usage
#worker_100.dispense(2)     # Dispense two 100 notes
#worker_1000.dispense(1)    # Dispense one 1000 note
#worker_100.reset()         # Reset 100 note dispenser

# Shutdown
#worker_100.stop()
#worker_500.stop()
#worker_1000.stop()
