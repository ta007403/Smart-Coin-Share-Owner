import re

def crc16_ccitt(data: str) -> int:
    """Calculate CRC16-CCITT (False)"""
    crc = 0xFFFF
    for c in data:
        crc ^= ord(c) << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ 0x1021
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc

def generate_promptpay_payload(phone_number: str, amount: float) -> str:
    # Clean phone number
    digits = re.sub(r'\D', '', phone_number)
    if digits.startswith('66'):
        pp_id = f"00{len(digits)}{digits}"
    else:
        aid = "A000000677010111"
        formatted_phone = "0066" + digits.lstrip('0')
        phone_len = len(formatted_phone)
        pp_id = (
            f"00{len(aid)}{aid}"
            f"01{phone_len:02}{formatted_phone}"
        )

    # Payload parts
    payload = ""
    payload += "000201"                  # Payload Format Indicator
    payload += "010212"                  # Point of Initiation Method
    payload += f"29{len(pp_id):02}{pp_id}" # Merchant Account Info
    payload += "52040000"                # Merchant Category Code
    payload += "5303764"                 # Currency (THB)
    amount_str = f"{amount:.2f}"
    payload += f"54{len(amount_str):02}{amount_str}" # Amount
    payload += "5802TH"                  # Country Code
    payload += "6304"                    # CRC placeholder

    # Calculate CRC16-CCITT
    crc = crc16_ccitt(payload)
    crc_hex = f"{crc:04X}"
    return payload + crc_hex

# Example usage
#payload = generate_promptpay_payload("0810228840", 100)
#print(payload)
