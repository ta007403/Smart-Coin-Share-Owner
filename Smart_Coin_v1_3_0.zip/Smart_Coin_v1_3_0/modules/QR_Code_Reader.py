from PyQt5.QtCore import QThread, pyqtSignal
import serial
import time
import threading

class QRCodeReader(QThread):
    code_scanned = pyqtSignal(str)

    def __init__(self, port="/dev/ttyUSB2", baudrate=9600): # This is a default port and baudrate
        super().__init__()
        self.port = port
        self.baudrate = baudrate
        self._running = True
        self._paused = False
        self.ser = None
        self.name = "QR code reader"

    def run(self):
        threading.current_thread().name = self.name
        while self._running:
            if self._paused:
                time.sleep(0.2)
                continue

            if not self.ser:
                try:
                    self.ser = serial.Serial(self.port, self.baudrate, timeout=1)
                    print(f"[QR] Connected to {self.port}")
                except Exception as e:
                    print(f"[QR] Serial open error: {e}")
                    time.sleep(2)
                    continue

            try:
                if self.ser.in_waiting:
                    data = self.ser.readline().decode('utf-8').strip()
                    if data:
                        print(f"[QR] Scanned: {data}")
                        self.code_scanned.emit(data)
            except Exception as e:
                print(f"[QR] Read error: {e}")
                try:
                    self.ser.close()
                except:
                    pass
                self.ser = None
                time.sleep(2)

            time.sleep(0.1)

        # Clean up on thread exit
        if self.ser:
            try:
                self.ser.close()
            except:
                pass

    def pause(self):
        self._paused = True

    def resume(self):
        self._paused = False

    def stop(self):
        self._running = False
        self.wait()
