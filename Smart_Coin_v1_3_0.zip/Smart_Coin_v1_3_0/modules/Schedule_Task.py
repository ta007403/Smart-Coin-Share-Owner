import threading
from datetime import datetime, timedelta
import pytz
import time as time_module
from datetime import time

# Mapping of section name to (hour, minute)
TIME_SECTIONS = {
    "morning": (4, 0),
    "evening": (22, 50)
}

class DailyTask:
    def __init__(self, section_name, timezone_str, task_func, run_on_startup=False):
        self.section_name = section_name
        self.timezone = pytz.timezone(timezone_str)
        self.task_func = task_func
        self._thread = None
        self._running = False
        self.run_on_startup = run_on_startup
        self.name = "DailyTask"

    def start(self):
        threading.current_thread().name = self.name
        if self._thread is None or not self._thread.is_alive():
            self._running = True
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()

    def stop(self):
        self._running = False

    def _worker(self):
        print(f"[SCHEDULER] Starting DailyTask for {self.section_name}")
        if self.run_on_startup:
            self.task_func()
        hour, minute = TIME_SECTIONS[self.section_name]
        while self._running:
            now = datetime.now(self.timezone)
            target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if target < now:
                target += timedelta(days=1)
            wait_seconds = (target - now).total_seconds()
            print(f"[SCHEDULER] {self.section_name}: waiting {wait_seconds/60:.2f} minutes")
            # Sleep in small increments for responsiveness to stop
            sleep_time = min(wait_seconds, 30)
            while self._running and wait_seconds > 0:
                time_module.sleep(min(sleep_time, wait_seconds))
                now = datetime.now(self.timezone)
                wait_seconds = (target - now).total_seconds()
                sleep_time = min(wait_seconds, 30)
            if not self._running:
                break
            # It's time to run the task
            print(f"[SCHEDULER] {self.section_name}: running scheduled task")
            try:
                self.task_func()
            except Exception as e:
                print(f"[SCHEDULER] Error in {self.section_name} task:", e)
            # Wait at least 61 seconds before next trigger (avoid double-triggering in the same minute)
            time_module.sleep(61)

    def get_time_section(now=None):
        if now is None:
            now = datetime.now()
        now_time = time(now.hour, now.minute)

        morning_start = time(*TIME_SECTIONS["morning"])
        evening_start = time(*TIME_SECTIONS["evening"])

        # Morning: 04:00 <= now < 22:50
        if morning_start <= now_time < evening_start:
            return "morning"
        else:
            # Else: 22:50 <= now < 04:00 (wraps around midnight)
            return "evening"