from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from PyQt5.QtCore import QThread, pyqtSignal
from urllib.parse import urlparse, parse_qs
from modules.JSON_Management import MoneyDataManager
from dotenv import load_dotenv
import json
import os
import socket
import subprocess
import threading

load_dotenv()

DATA_CONFIG_JSON_FILE = os.getenv("DATA_CONFIG_JSON_FILE")
if DATA_CONFIG_JSON_FILE is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

API_SERVER_TOKEN_FOR_DASHBOARD = os.getenv("API_SERVER_TOKEN_FOR_DASHBOARD")
if API_SERVER_TOKEN_FOR_DASHBOARD is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

def load_data():
    default_data = {
        "information": {
            "location": "N/A",
            "Machine ID": "N/A",
            "IP Address": "N/A",
            "Telephone Number": "N/A",
            "Bank Account Number": "N/A",
            "Bank Account Name": "N/A",
            "Bank Provider": "N/A"
        },
        "configuration": {
            "Need to Update NFC Database": "No",
            "Amount of NFC Wallet": "No",
            "Withdraw Enable": "No",
            "Bank Transfer Enable": "No"
        },
        "coins inside the box": {
            "1": 0,
            "2": 0,
            "5": 0,
            "10": 0
        },
        "banknotes inside the box": {
            "20": 0,
            "50": 0,
            "100": 0,
            "500": 0,
            "1000": 0
        },
        "total coins value in the box": 0,
        "total banknotes value in the box": 0,
        "total physical money value in the box": 0,
        "customer transferred amount": 0,
        "banknotes_in_the_cassette_at_the_beginning": {
            "100": 0,
            "500": 0,
            "1000": 0
        },
        "current banknotes in the cassette": {
            "100": 0,
            "500": 0,
            "1000": 0
        },
        "total Withdraw Amount": 0
    }

    if os.path.exists(DATA_CONFIG_JSON_FILE):
        with open(DATA_CONFIG_JSON_FILE, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                print("JSON file is corrupted or invalid.")
                return default_data
    else:
        return default_data

def save_data(state):
    print("SAVING DATA! from server API")
    try:
        with open(DATA_CONFIG_JSON_FILE, "w") as f:
            json.dump(state, f, indent=2)
        print("Data saved to", DATA_CONFIG_JSON_FILE)
    except Exception as e:
        print("Error saving data:", e)

class APIServerWorker(QThread):
    server_started = pyqtSignal()
    server_stopped = pyqtSignal()

    def __init__(self, host, port, handler_class, parent=None):
        super().__init__(parent)
        self.host = host
        self.port = port
        self.handler_class = handler_class
        self._server = None
        self.name = "Server API"

    def run(self):
        threading.current_thread().name = self.name
        print(f"[APIServerWorker] Starting API server at http://{self.host}:{self.port}")
        self._server = ThreadingHTTPServer((self.host, self.port), self.handler_class)
        self.server_started.emit()
        try:
            self._server.serve_forever()
        except Exception as e:
            print(f"[APIServerWorker] Server stopped with exception: {e}")
        finally:
            self._server.server_close()
            print("[APIServerWorker] API server stopped")
            self.server_stopped.emit()

    def stop(self):
        print("[APIServerWorker] Shutting down server...")
        if self._server:
            # Shutdown in another thread to prevent blocking
            threading.Thread(target=self._server.shutdown).start()
        self.quit()
        self.wait()

class Server_API_Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        token = query.get("token", [None])[0]
        #print("DEBUG parsed.path:", parsed.path)

        if token != API_SERVER_TOKEN_FOR_DASHBOARD:
            self.send_response(403)
            self.end_headers()
            self.wfile.write(b"Unauthorized")
            return

        if parsed.path == "/status":
            state = load_data()
            #print("DEBUG state:", state, type(state))
            if isinstance(state, list):
                print("WARNING: state is a list! Picking first item.")
                if state:  # Not empty
                    state = state[0]
                else:
                    state = {}  # Default to empty dict

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()

            coins = state.get("coins inside the box", {})
            banknotes = state.get("banknotes inside the box", {})

            total_coins = sum(int(k) * v for k, v in coins.items())
            total_banknotes = sum(int(k) * v for k, v in banknotes.items())
            total_physical_money = total_coins + total_banknotes

            manager = MoneyDataManager()
            manager.set_total_coins_value(total_coins)
            manager.set_total_banknotes_value(total_banknotes)
            manager.set_total_physical_money_value(total_physical_money)

            response = {
                "information": state.get("information", {}),
                "configuration": state.get("configuration", {}),
                "coins inside the box": coins,
                "banknotes inside the box": banknotes,
                "total coins value in the box": total_coins,
                "total banknotes value in the box": total_banknotes,
                "total physical money value in the box": total_physical_money,
                "customer transferred amount": state.get("customer transferred amount", 0),
                "banknotes_in_the_cassette_at_the_beginning": state.get("banknotes_in_the_cassette_at_the_beginning", {}),
                "current banknotes in the cassette": state.get("current banknotes in the cassette", {}),
                "total Withdraw Amount": state.get("total Withdraw Amount", 0)
            }

            self.wfile.write(json.dumps(response, indent=2).encode())

        elif parsed.path == "/resetDepositStat":
            state = load_data()
            #print("DEBUG state:", state, type(state))
            if isinstance(state, list):
                print("WARNING: state is a list! Picking first item.")
                if state:  # Not empty
                    state = state[0]
                else:
                    state = {}  # Default to empty dict

            for k in state["coins inside the box"]:
                state["coins inside the box"][k] = 0
            for k in state["banknotes inside the box"]:
                state["banknotes inside the box"][k] = 0
            state["customer transferred amount"] = 0
            state["total coins value"] = 0
            state["total banknotes value"] = 0
            state["total physical money value"] = 0

            save_data(state)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "reset done"}')

        elif parsed.path == "/big_sync_nfc":
            state = load_data()
            #print("DEBUG state:", state, type(state))
            if isinstance(state, list):
                print("WARNING: state is a list! Picking first item.")
                if state:  # Not empty
                    state = state[0]
                else:
                    state = {}  # Default to empty dict

            state.setdefault("configuration", {})["Need to Update NFC Database"] = "Yes"
            save_data(state)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "NFC sync flag set to Yes"}')

        elif parsed.path == "/resetWithdrawalStat":
            state = load_data()
            #print("DEBUG state:", state, type(state))
            if isinstance(state, list):
                print("WARNING: state is a list! Picking first item.")
                if state:  # Not empty
                    state = state[0]
                else:
                    state = {}  # Default to empty dict

            state["total Withdraw Amount"] = 0

            save_data(state)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "reset done"}')

        elif parsed.path.startswith("/setNotes100="):
            try:
                amount = int(parsed.path.split("=")[1])
            except (IndexError, ValueError):
                self.send_error(400, "Invalid amount")
                return

            state = load_data()
            if isinstance(state, list):
                print("WARNING: state is a list! Picking first item.")
                state = state[0] if state else {}

            cassette = state.setdefault("banknotes_in_the_cassette_at_the_beginning", {"100": 0, "500": 0, "1000": 0})
            cassette["100"] = amount

            save_data(state)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "set 100 done"}')

        elif parsed.path.startswith("/setNotes500="):
            try:
                amount = int(parsed.path.split("=")[1])
            except (IndexError, ValueError):
                self.send_error(400, "Invalid amount")
                return

            state = load_data()
            if isinstance(state, list):
                print("WARNING: state is a list! Picking first item.")
                state = state[0] if state else {}

            cassette = state.setdefault("banknotes_in_the_cassette_at_the_beginning", {"100": 0, "500": 0, "1000": 0})
            cassette["500"] = amount

            save_data(state)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "set 500 done"}')

        elif parsed.path.startswith("/setNotes1000="):
            try:
                amount = int(parsed.path.split("=")[1])
            except (IndexError, ValueError):
                self.send_error(400, "Invalid amount")
                return

            state = load_data()
            if isinstance(state, list):
                print("WARNING: state is a list! Picking first item.")
                state = state[0] if state else {}

            cassette = state.setdefault("banknotes_in_the_cassette_at_the_beginning", {"100": 0, "500": 0, "1000": 0})
            cassette["1000"] = amount

            save_data(state)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "set 1000 done"}')

        # This is for show command not found response
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not found")

    def log_message(self, format, *args):
        return  # Suppress log output

def get_ip_address(ifname):
    import socket, fcntl, struct
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        ip_bytes = fcntl.ioctl(
            s.fileno(),
            0x8915,  # SIOCGIFADDR
            struct.pack('256s', ifname[:15].encode('utf-8'))
        )[20:24]
        return socket.inet_ntoa(ip_bytes)
    except OSError:
        return None

def update_IP_Linux():
    ip_address = get_ip_address('wlan0') or get_ip_address('eth0')
    if not ip_address:
        print("Could not determine IP address.")
        return None

    # Load the JSON file
    if os.path.exists(DATA_CONFIG_JSON_FILE):
        with open(DATA_CONFIG_JSON_FILE, 'r') as f:
            data = json.load(f)
    else:
        print(f"JSON file {DATA_CONFIG_JSON_FILE} not found.")
        return None

    data['information']['IP Address'] = ip_address
    with open(DATA_CONFIG_JSON_FILE, 'w') as f:
        json.dump(data, f, indent=2)
    print(f"IP address updated to {ip_address}")
    return ip_address
