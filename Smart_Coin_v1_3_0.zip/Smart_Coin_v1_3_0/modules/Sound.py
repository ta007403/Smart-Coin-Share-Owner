from PyQt5.QtCore import QTimer
import threading
import queue
import os
import time

SOUND_DEBOUCE_TIME = 300  # milliseconds
_debounce = False

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

SOUND_FILES = {
    1: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Cha_Ching.wav')),
    2: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/High_Tech_Long.wav')),
    3: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/High_Tech_Short.wav')),
    4: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/macOS.wav')),
    5: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Touch.wav')),
    6: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Success.wav')),
    7: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Meme.wav')),
    8: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Police_Siren.wav')),
    9: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Error.wav')),
    10: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Button_Press.wav')),
    11: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Mario_Coin_Sound.wav')),
    12: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Load_1.wav')),
    13: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Load_2.wav')),
    14: os.path.abspath(os.path.join(BASE_DIR, '../assets/sounds/Whoop.wav'))
}

# Preload all sounds into a dictionary
for idx, file_path in SOUND_FILES.items():
    if not os.path.isfile(file_path):
        print(f"[Sound Warning] File not found for index {idx}: {file_path}")

# Create a sound queue
sound_queue = queue.Queue()

def sound_worker():
    while True:
        idx = sound_queue.get()
        sound = PRELOADED_SOUNDS.get(idx)
        if sound:
            try:
                sound.play()
            except Exception as e:
                print(f"[SoundWorker Error] {e}")
        else:
            print(f"[SoundWorker] No preloaded sound for index: {idx}")
        sound_queue.task_done()

# Start the sound worker thread
threading.Thread(target=sound_worker, daemon=True).start()

def play_sound_by_index(index):
    global _debounce
    if _debounce:
        return
    _debounce = True

    file = SOUND_FILES.get(index)
    if file and os.path.isfile(file):
        os.system(f"aplay '{file}' > /dev/null 2>&1 &")
    else:
        print(f"[WARN] No sound file for index: {index}")

    QTimer.singleShot(SOUND_DEBOUCE_TIME, reset_debounce)

def reset_debounce():
    global _debounce
    _debounce = False

# Usage Example:
# play_sound_by_index(1)
