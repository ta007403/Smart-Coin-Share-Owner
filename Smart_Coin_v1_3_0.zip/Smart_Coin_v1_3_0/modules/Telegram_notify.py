import threading
import requests
import os
from dotenv import load_dotenv

load_dotenv()

CHAT_TOKEN = os.getenv("CHAT_TOKEN")
if CHAT_TOKEN is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

CHAT_ID = os.getenv("CHAT_ID")
if CHAT_ID is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

#https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates
# But you have to remove < and > after /bot

def telegram(message):
    #print(f"CHAT_TOKEN : {CHAT_TOKEN}")
    #print(f"CHAT_ID : {CHAT_ID}")
    url = f"https://api.telegram.org/bot{CHAT_TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID,
        "text": message,
        "parse_mode": "HTML"  # or "Markdown"
    }
    response = requests.post(url, data=payload)
    return response.json()

def telegram_worker(message):
    thread = threading.Thread(target=telegram, args=(message,))
    thread.daemon = True  # allows program to exit even if this thread is running
    thread.start()

# Example usage:
#if __name__ == "__main__":
#    text = "Hello from Python! 👋 what the fuck are you doing man"
#    resp = telegram_notify(text)
#    print(resp)
