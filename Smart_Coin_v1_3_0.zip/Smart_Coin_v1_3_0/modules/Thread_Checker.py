from PyQt5.QtCore import QThread, pyqtSignal
import threading
import time

class WatchdogChecker(QThread):
    # Example: signal when BTC price should update (you can add more)
    status_report = pyqtSignal(list)  # List of alive thread names

    def __init__(self, refresh_interval=60, parent=None):
        super().__init__(parent)
        self.refresh_interval = refresh_interval
        self.running = True
        self.name = "Thread Monitor"

    def run(self):
        threading.current_thread().name = self.name
        while self.running:
            # Here’s your periodic check!
            alive_threads = [t.name for t in threading.enumerate()]
            self.status_report.emit(alive_threads)  # Emit list of alive thread names

            time.sleep(self.refresh_interval)

    def stop(self):
        self.running = False
