import threading
import time
from datetime import datetime, timedelta
import pytz

# This class is use for animate loading bar
class TimerTask:
    def __init__(self, duration, on_trigger):
        self.duration = duration  # seconds
        self.on_trigger = on_trigger
        self._thread = None
        self._running = False
        self.name = "Timer"

    def start(self):
        threading.current_thread().name = self.name
        if self._thread is None or not self._thread.is_alive():
            self._running = True
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()

    def stop(self):
        self._running = False

    def _worker(self):
        while self._running:
            elapsed = 0
            interval = 0.2  # check stop every 0.2 sec (200 ms)
            while elapsed < self.duration and self._running:
                time.sleep(interval)
                elapsed += interval
            if self._running:  # Only trigger if still running
                try:
                    self.on_trigger()
                except Exception as e:
                    print("[SCHEDULER] Error in timer task:", e)