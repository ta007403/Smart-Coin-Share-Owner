from flask import render_template_string, request, redirect, url_for, session, abort, Flask, jsonify
import json
import os
from dotenv import load_dotenv
from functools import wraps
import threading

load_dotenv()

DATA_CONFIG_JSON_FILE = os.getenv("DATA_CONFIG_JSON_FILE")
if DATA_CONFIG_JSON_FILE is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

API_SERVER_TOKEN_FOR_DASHBOARD = os.getenv("API_SERVER_TOKEN_FOR_DASHBOARD")
if API_SERVER_TOKEN_FOR_DASHBOARD is None:
    raise RuntimeError(".env file is not set. Please check your .env file!")

if not os.path.exists(DATA_CONFIG_JSON_FILE):
    raise RuntimeError(f"Config file not found: {DATA_CONFIG_JSON_FILE}")

with open(DATA_CONFIG_JSON_FILE, "r", encoding="utf-8") as f:
    data = json.load(f)

dashboard_flask_app = Flask(__name__)
dashboard_flask_app.secret_key = API_SERVER_TOKEN_FOR_DASHBOARD

def require_login(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = session.get('api_token')
        if not token or token != API_SERVER_TOKEN_FOR_DASHBOARD:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@dashboard_flask_app.route('/logout')
def logout():
    session.pop('api_token', None)
    return redirect(url_for('login'))

def require_api_key_decorator(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.args.get("token")
        if not token or token != API_SERVER_TOKEN_FOR_DASHBOARD:
            abort(401)
        return f(*args, **kwargs)
    return decorated

@dashboard_flask_app.route('/error')
def error_page():
    return render_template_string("""
        <h1>🚫 Access Denied</h1>
        <p>This page is not available. Please use the API endpoint with your token.</p>
    """), 403

#def save_data_to_file():
#    print("SAVING DATA! from web dashboard")
#    with open(DATA_CONFIG_JSON_FILE, "w", encoding="utf-8") as f:
#        json.dump(data, f, ensure_ascii=False, indent=2)

def save_data_to_file(fresh_data):
    with open(DATA_CONFIG_JSON_FILE, "w", encoding="utf-8") as f:
        json.dump(fresh_data, f, ensure_ascii=False, indent=2)

def load_data_from_file():
    with open(DATA_CONFIG_JSON_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

@dashboard_flask_app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        token = request.form.get('token')
        if not token or token != API_SERVER_TOKEN_FOR_DASHBOARD:
            error = "Invalid API Token!"
        else:
            session['api_token'] = token
            return redirect(url_for('index'))
    return render_template_string("""
    <html>
    <head>
      <title>Login</title>
      <style>
        body { font-family: Arial; background:#f4f8fb; }
        .login-box { max-width:350px; margin:100px auto; background:#fff; padding:30px; border-radius:14px; box-shadow:0 3px 18px #ccc;}
        h2 { text-align:center; }
        .error { color:#d7263d; margin-bottom:10px;}
        button {
            width: 100%;
            padding: 12px;
            background: #1687a7;
            color: #fff;
            font-size: 1em;
            border: none;
            border-radius: 5px;
            transition: background 0.2s;
            cursor: pointer;
        }
        button:hover {
            background: #ffa930;
        }
      </style>
    </head>
    <body>
      <div class="login-box">
        <h2>Login</h2>
        {% if error %}<div class="error">{{ error }}</div>{% endif %}
        <form method="post">
          <input type="password" name="token" placeholder="API Token" style="width:100%;padding:12px;margin-bottom:14px;" autofocus required>
          <button>Login</button>
        </form>
      </div>
    </body>
    </html>
    """, error=error)

@dashboard_flask_app.route('/api/status')
@require_login
def api():
    fresh_data = load_data_from_file()
    return jsonify(fresh_data)

@dashboard_flask_app.route('/')
@require_login
def index():
    return render_template_string("""
    <html>
    <head>
      <title>Smart Coin Dashboard</title>
      <style>
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          background: #f4f8fb;
          color: #222;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 820px;
          margin: 40px auto;
          padding: 20px;
        }
        h1 {
          text-align: center;
          font-size: 2.5em;
          font-weight: bold;
          margin-bottom: 28px;
          color: #276678;
        }
        .card {
          background: #ffffff;
          border-radius: 15px;
          box-shadow: 0 2px 16px rgba(39, 102, 120, 0.11);
          padding: 28px 22px 18px 22px;
          margin-bottom: 28px;
        }
        .card-title {
          font-size: 1.25em;
          color: #1687a7;
          margin-bottom: 10px;
          font-weight: 600;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 10px;
        }
        th, td {
          padding: 7px 0;
          text-align: left;
        }
        th {
          background: #e5ecf6;
          color: #276678;
        }
        tr:nth-child(even) {background: #f4f8fb;}
        .stat-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 10px;
        }
        .stat-label {
          color: #1687a7;
        }
        .stat-value {
          font-weight: bold;
        }
        .info-list, .config-list {
          list-style: none;
          padding-left: 0;
        }
        .info-list li, .config-list li {
          margin-bottom: 7px;
          display: flex;
          justify-content: space-between;
        }
        .info-key, .config-key {
          color: #276678;
          font-weight: 500;
        }
        .info-value, .config-value {
          font-weight: 400;
        }
      </style>
      <script>
        async function loadData() {
          let res = await fetch('/api/status');
          let data = await res.json();

          // Machine Info
          const infoOrder = [
            "location",
            "Machine ID",
            "IP Address",
            "Telephone Number",
            "Bank Account Number",
            "Bank Account Name",
            "Bank Provider",
            "Smart Coin Hardware Version",
            "Smart Coin Software Version",
            "Arduino GSM Version"
          ];
          
          let infoList = '';
          for (let i = 0; i < infoOrder.length; i++) {
            const key = infoOrder[i];
            infoList += `<li><span class="info-key">${key}:</span> <span class="info-value">${data["information"][key]}</span></li>`;
          }
          document.getElementById('info-list').innerHTML = infoList;

          // Configuration
          const configOrder = [
            "Amount of NFC Wallet",
            "Need to Update NFC Database",
            "Bank Transfer Enable",
            "Withdraw Enable"
          ];
          
          let configList = '';
          for (let i = 0; i < configOrder.length; i++) {
            const key = configOrder[i];
            configList += `<li><span class="config-key">${key}:</span> <span class="config-value">${data["configuration"][key]}</span></li>`;
          }
          document.getElementById('config-list').innerHTML = configList;

          // Coins Table
          let coinsRows = '';
          for (let coin in data["coins inside the box"]) {
            coinsRows += `<tr><td>${coin} บาท</td><td>${data["coins inside the box"][coin]}</td></tr>`;
          }
          document.getElementById('coins-table').innerHTML = coinsRows;

          // Banknotes Table
          let bankRows = '';
          for (let note in data["banknotes inside the box"]) {
            bankRows += `<tr><td>${note} บาท</td><td>${data["banknotes inside the box"][note]}</td></tr>`;
          }
          document.getElementById('bank-table').innerHTML = bankRows;

          // Cassette at the beginning
          let cassetteBeginRows = '';
          for (let note in data["banknotes_in_the_cassette_at_the_beginning"]) {
            cassetteBeginRows += `<tr><td>${note} บาท</td><td>${data["banknotes_in_the_cassette_at_the_beginning"][note]}</td></tr>`;
          }
          document.getElementById('cassette-begin-table').innerHTML = cassetteBeginRows;

          // Cassette current
          let cassetteCurrentRows = '';
          for (let note in data["current banknotes in the cassette"]) {
            cassetteCurrentRows += `<tr><td>${note} บาท</td><td>${data["current banknotes in the cassette"][note]}</td></tr>`;
          }
          document.getElementById('cassette-current-table').innerHTML = cassetteCurrentRows;

          // Stats
          document.getElementById('stat-coins').innerText = Number(data["total coins value in the box"]).toLocaleString('en-US') + " บาท";
          document.getElementById('stat-banknotes').innerText = Number(data["total banknotes value in the box"]).toLocaleString('en-US') + " บาท";
          document.getElementById('stat-total').innerText = Number(data["total physical money value in the box"]).toLocaleString('en-US') + " บาท";
          document.getElementById('stat-transferred').innerText = Number(data["customer transferred amount"]).toLocaleString('en-US') + " บาท";
          document.getElementById('stat-withdraw').innerText = Number(data["total Withdraw Amount"]).toLocaleString('en-US') + " บาท";
        }
        
        function syncNFC() {
          fetch('/api/sync-nfc', {method: 'POST'})
            .then(res => res.json())
            .then(data => {
              alert(data.message);
              location.reload(); // <-- This will fetch the updated value!
            })
            .catch(err => alert('Error: ' + err));
        }

        function resetStats() {
          if (!confirm("Are you sure you want to reset all statistics?")) return;
          fetch('/api/reset-stats', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
              alert(data.message);
              loadData(); // Reload dashboard data after reset
            })
            .catch(err => alert('Error resetting statistics: ' + err));
        }
        
      </script>
    </head>
    <body onload="loadData()">
      <div class="container">
        <h1>Smart Coin Dashboard</h1>
        
        <div class="card">
          <div class="card-title">Machine Information</div>
          <ul class="info-list" id="info-list"></ul>
        </div>
        
        <style>
        .orange-btn {
            padding: 8px 22px;
            background: #ffa930;
            color: white;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1em;
            box-shadow: 0 2px 6px #eee;
            cursor: pointer;
            transition: background 0.18s;
            display: inline-block;
        }
        .orange-btn:hover {
            background: #c97b18;
        }
        </style>

        <div style="height: 10px;"></div>
        <div style="text-align: right; margin-bottom: 32px;">
          <a href="/edit-info" class="orange-btn">
            ✎ Edit Information
          </a>
        </div>
        
        <div class="card">
          <div class="card-title">Configuration</div>
          <ul class="config-list" id="config-list"></ul>
        </div>

        <style>
        .red-btn {
            padding: 8px 22px;
            background: #ff5959;
            color: white;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1em;
            box-shadow: 0 2px 6px #eee;
            cursor: pointer;
            transition: background 0.18s;
            display: inline-block;
        }
        .red-btn:hover {
            background: #d7263d;  /* deeper red on hover */
        }
        </style>

        <div style="height: 10px;"></div>
        <div style="text-align: right; margin-bottom: 32px;">
          <a href="/edit-config" class="orange-btn">
            ⚙️ Edit Configuration
          </a>
        </div>
        
        <div class="card">
          <div class="card-title">Banknotes in Cassette (At Beginning)</div>
          <table>
            <tr><th>Denomination</th><th>Count</th></tr>
            <tbody id="cassette-begin-table"></tbody>
          </table>
        </div>
        
        <div class="card">
          <div class="card-title">Current Banknotes in Cassette</div>
          <table>
            <tr><th>Denomination</th><th>Count</th></tr>
            <tbody id="cassette-current-table"></tbody>
          </table>
        </div>
        
        <div class="card">
          <div class="card-title">Withdrawal Summary</div>
          <div class="stat-row">
            <span class="stat-label">Total Withdraw Amount:</span>
            <span class="stat-value" id="stat-withdraw"></span>
          </div>
        </div>
        
        <style>
        .orange-btn {
            padding: 8px 22px;
            background: #ffa930;
            color: white;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1em;
            box-shadow: 0 2px 6px #eee;
            cursor: pointer;
            transition: background 0.18s;
            display: inline-block;
        }
        .orange-btn:hover {
            background: #c97b18; /* Deeper orange on hover */
        }
        </style>

        <div style="height: 10px;"></div>
        <div style="text-align: right; margin-bottom: 32px;">
          <a href="/edit-cassette-begin" class="orange-btn">
            🗄️ Edit Cassette At Beginning
          </a>
        </div>
        
        <div class="card">
          <div class="card-title">Banknotes Inside the Box</div>
          <table>
            <tr><th>Denomination</th><th>Count</th></tr>
            <tbody id="bank-table"></tbody>
          </table>
        </div>
        
        <div class="card">
          <div class="card-title">Coins Inside the Box</div>
          <table>
            <tr><th>Denomination</th><th>Count</th></tr>
            <tbody id="coins-table"></tbody>
          </table>
        </div>
        
        <div class="card">
          <div class="card-title">Deposit Summary</div>
          <div class="stat-row">
            <span class="stat-label">Total Coins In The Box:</span>
            <span class="stat-value" id="stat-coins"></span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Total Banknotes In The Box:</span>
            <span class="stat-value" id="stat-banknotes"></span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Total Physical Money In The Box:</span>
            <span class="stat-value" id="stat-total"></span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Customer Transferred Amount:</span>
            <span class="stat-value" id="stat-transferred"></span>
          </div>
        </div>
        
        <style>
        .orange-btn {
            padding: 8px 22px;
            background: #ffa930;
            color: white;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1em;
            box-shadow: 0 2px 6px #eee;
            cursor: pointer;
            transition: background 0.18s;
            display: inline-block;
        }
        .orange-btn:hover {
            background: #c97b18; /* Deeper orange on hover */
        }
        </style>

        <div style="height: 10px;"></div>
        <div style="text-align: right; margin-bottom: 32px;">
          <button onclick="resetStats()" class="orange-btn">
            🧹 Reset Statistics
          </button>
        </div>

        <div style="height: 10px;"></div>
        <div style="text-align: right; margin-bottom: 32px;">
          <button onclick="loadData()" style="
            margin-top: 10px;
            margin-bottom: 20px;
            padding: 8px 20px;
            background: #1687a7;
            color: white;
            border: none;
            border-radius: 7px;
            font-weight: 600;
            box-shadow: 0 1px 5px #eee;
            cursor: pointer;
            font-size: 1em;
            transition: background 0.18s;
            display: inline-block;
          " onmouseover="this.style.background='#d7263d'" onmouseout="this.style.background='#1687a7'">
            🔄 Refresh

          </button>
          <a href="/logout" style="
              margin-top: 10px;
              margin-bottom: 20px;
              padding: 8px 20px;
              background: #ff5959;
              color: white;
              border: none;
              border-radius: 7px;
              font-weight: 600;
              font-size: 1em;
              box-shadow: 0 1px 5px #eee;
              text-decoration: none;
              cursor: pointer;
              transition: background 0.18s;
              display: inline-block;
          " onmouseover="this.style.background='#d7263d'" onmouseout="this.style.background='#ff5959'">
            🚪 Logout
          </a>
        </div>
        
      </div>
    </body>
    </html>
    """)

@dashboard_flask_app.route('/api/update-cassette-begin', methods=['POST'])
@require_login
def update_cassette_begin():
    fresh_data = load_data_from_file()
    # Mock: Just print current cassette data to terminal
    print("=== Cassette At Beginning (Update Requested) ===")
    for denom, count in fresh_data["banknotes_in_the_cassette_at_the_beginning"].items():
        print(f"{denom} บาท : {count}")
    print("===============================================")
    return jsonify({"message": "Cassette (At Beginning) update triggered! (See terminal)"})

@dashboard_flask_app.route('/edit-info', methods=['GET', 'POST'])
@require_login
def edit_info():
    fresh_data = load_data_from_file()
    editable_keys = [
        "location",
        "Machine ID",
        "Telephone Number",
        "Bank Account Number",
        "Bank Account Name",
        "Bank Provider",
        "Smart Coin Hardware Version"
    ]
    if request.method == 'POST':
        for key in editable_keys:
            fresh_data["information"][key] = request.form.get(key, fresh_data["information"][key])
        save_data_to_file(fresh_data)
        print("=== Machine Info Updated! ===")
        print(fresh_data["information"])
        print("============================")
        return "<script>alert('Updated!');window.location='/'</script>"

    # Card-style HTML with improved CSS
    html = """
    <html>
    <head>
      <title>Edit Machine Information</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
        body {
          background: #f4f8fb;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          margin: 0;
        }
        .container {
          max-width: 480px;
          margin: 50px auto;
          padding: 0 12px;
        }
        .card {
          background: #fff;
          border-radius: 18px;
          box-shadow: 0 2px 16px rgba(39,102,120,0.12);
          padding: 38px 30px 26px 30px;
          margin-bottom: 24px;
          transition: box-shadow 0.2s;
        }
        .card:hover {
          box-shadow: 0 6px 32px rgba(39,102,120,0.17);
        }
        h2 {
          margin-top: 0;
          text-align: center;
          color: #276678;
          font-size: 2em;
          margin-bottom: 26px;
        }
        .form-group {
          margin-bottom: 18px;
        }
        label {
          display: block;
          color: #1687a7;
          font-weight: 600;
          margin-bottom: 7px;
        }
        input[type="text"], input[type="tel"], input[type="number"] {
          width: 100%;
          padding: 10px 14px;
          border: 1.2px solid #e5ecf6;
          border-radius: 7px;
          font-size: 1.08em;
          margin-top: 3px;
          background: #f7fbfd;
          transition: border-color 0.15s;
        }
        input:focus {
          border-color: #ffa930;
          outline: none;
          background: #fffbe7;
        }
        .btn-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 28px;
        }
        .btn {
          padding: 11px 30px;
          background: #1687a7;
          color: #fff;
          border: none;
          border-radius: 7px;
          font-weight: 700;
          font-size: 1em;
          box-shadow: 0 1px 5px #eee;
          cursor: pointer;
          transition: background 0.18s;
        }
        .btn:hover {
          background: #ffa930;
        }
        .back-link {
          color: #1687a7;
          text-decoration: none;
          font-weight: 500;
          font-size: 1em;
        }
        @media (max-width: 600px) {
          .card {
            padding: 18px 8px 15px 8px;
          }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="card">
          <h2>Edit Machine Information</h2>
          <form method="post" autocomplete="off">
    """

    # Dynamically add form fields
    for key in editable_keys:
        val = fresh_data["information"].get(key, "")
        html += f"""
          <div class="form-group">
            <label for="{key}">{key}</label>
            <input 
              type="text" 
              name="{key}" 
              id="{key}" 
              value="{val}" 
              required
            >
          </div>
        """

    html += """
            <div class="btn-row">
              <button type="submit" class="btn">💾 Save</button>
              <a href="/" class="back-link">&larr; Back</a>
            </div>
          </form>
        </div>
      </div>
    </body>
    </html>
    """
    return html

@dashboard_flask_app.route('/api/sync-nfc', methods=['POST'])
@require_login
def sync_nfc():
    fresh_data = load_data_from_file()
    # Step 1: Change value in memory
    fresh_data["configuration"]["Need to Update NFC Database"] = "Yes"
    # Step 2: Write to disk
    save_data_to_file(fresh_data)
    # Step 2: Print a mock "sync" action
    print("=== NFC Sync Triggered! ===")
    print("===========================")
    return jsonify({"message": "NFC Sync triggered! (please wait until 4:00 AM in the morning)"})

@dashboard_flask_app.route('/edit-config', methods=['GET', 'POST'])
@require_login
def edit_config():
    fresh_data = load_data_from_file()
    if request.method == 'POST':
        fresh_data["configuration"]["Bank Transfer Enable"] = request.form.get("Bank Transfer Enable", "No")
        fresh_data["configuration"]["Withdraw Enable"] = request.form.get("Withdraw Enable", "No")

        save_data_to_file(fresh_data)

        print("=== Configuration Updated! ===")
        print(fresh_data["configuration"])
        print("============================")
        return "<script>alert('Configuration Updated!');window.location='/'</script>"

    conf = fresh_data["configuration"]
    return render_template_string("""
    <html>
    <head>
      <title>Edit Configuration</title>
      <style>
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          background: #f4f8fb;
          color: #222;
        }
        .container {
          max-width: 500px;
          margin: 60px auto;
          padding: 36px 24px;
          background: #fff;
          border-radius: 15px;
          box-shadow: 0 2px 16px rgba(39, 102, 120, 0.11);
        }
        h2 { color: #1687a7; margin-bottom: 24px; }
        label { font-weight: 500; color: #276678; }
        select, button {
          margin-top: 6px;
          padding: 7px 12px;
          border-radius: 6px;
          border: 1px solid #ccc;
          cursor: pointer;
        }
        button {
          background: #ff5959;
          color: white;
          border: none;
          font-weight: 600;
          margin-right: 10px;
          cursor: pointer;
        }
        .row { margin-bottom: 18px; }
        .right { text-align: right; }
        .back-link { margin-top: 30px; display: block; color: #1687a7; }
      </style>
      <script>
        function syncNFC() {
          fetch('/api/sync-nfc', {method: 'POST'})
            .then(res => res.json())
            .then(data => alert(data.message))
            .catch(err => alert('Error: ' + err));
        }
      </script>
    </head>
    <body>
      <div class="container">
        <h2>Edit Configuration</h2>
        <form method="post">
          <div class="row">
            <label>Bank Transfer Enable:<br>
              <select name="Bank Transfer Enable" style="width:200px;">
                <option value="Yes" {% if conf["Bank Transfer Enable"] == "Yes" %}selected{% endif %}>Yes</option>
                <option value="No" {% if conf["Bank Transfer Enable"] == "No" %}selected{% endif %}>No</option>
              </select>
            </label>
          </div>
          <div class="row">
            <label>Withdraw Enable:<br>
              <select name="Withdraw Enable" style="width:200px;">
                <option value="Yes" {% if conf["Withdraw Enable"] == "Yes" %}selected{% endif %}>Yes</option>
                <option value="No" {% if conf["Withdraw Enable"] == "No" %}selected{% endif %}>No</option>
              </select>
            </label>
          </div>
          <div class="right">
            <button type="submit">Save Configuration</button>
            <button type="button" onclick="syncNFC()" style="background:#ffa930; cursor:pointer;">Sync NFC Database</button>
          </div>
        </form>
        <a href="/" class="back-link">&larr; Back to Dashboard</a>
      </div>
    </body>
    </html>
    """, conf=conf)

@dashboard_flask_app.route('/edit-cassette-begin', methods=['GET', 'POST'])
@require_login
def edit_cassette_begin():
    fresh_data = load_data_from_file()
    denominations = ["100", "500", "1000"]
    if request.method == 'POST':
        for denom in denominations:
            val = request.form.get(f"cassette_{denom}", "")
            try:
                count = int(val)
            except Exception:
                count = 0
            # Update both "begin" and "current"
            fresh_data["banknotes_in_the_cassette_at_the_beginning"][denom] = count
            fresh_data["current banknotes in the cassette"][denom] = count
            fresh_data["total Withdraw Amount"] = 0
        save_data_to_file(fresh_data)
        print("=== Cassette At Beginning Updated ===")
        print("Begin:", fresh_data["banknotes_in_the_cassette_at_the_beginning"])
        print("Current:", fresh_data["current banknotes in the cassette"])
        print("====================================")
        return "<script>alert('Cassette updated!');window.location='/'</script>"

    # Pre-fill with current values
    begin = fresh_data["banknotes_in_the_cassette_at_the_beginning"]
    html = """
    <html>
    <head>
      <title>Edit Cassette At Beginning</title>
      <style>
        body { background: #f4f8fb; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .container { max-width: 420px; margin: 60px auto; }
        .card {
          background: #fff;
          border-radius: 16px;
          box-shadow: 0 2px 14px rgba(39,102,120,0.13);
          padding: 32px 22px 24px 22px;
          margin-bottom: 24px;
        }
        h2 { text-align: center; color: #276678; margin-top: 0; }
        .form-group { margin-bottom: 22px; }
        label { color: #1687a7; font-weight: 600; }
        input[type="number"] {
          width: 120px;
          padding: 9px 10px;
          font-size: 1.06em;
          border: 1.2px solid #e5ecf6;
          border-radius: 7px;
          background: #f7fbfd;
          margin-left: 12px;
        }
        input:focus { border-color: #ffa930; outline: none; background: #fffbe7; }
        .btn-row { display: flex; justify-content: space-between; align-items: center; margin-top: 30px; }
        .btn {
          padding: 10px 28px;
          background: #1687a7;
          color: #fff;
          border: none;
          border-radius: 7px;
          font-weight: 700;
          font-size: 1em;
          cursor: pointer;
          transition: background 0.18s;
        }
        .btn:hover { background: #ffa930; }
        .back-link { color: #1687a7; text-decoration: none; font-weight: 500; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="card">
          <h2>Update Cassette At Beginning</h2>
          <form method="post" autocomplete="off">
    """
    for denom in denominations:
        val = begin.get(denom, 0)
        html += f"""
            <div class="form-group">
              <label for="cassette_{denom}">{denom} บาท:</label>
              <input type="number" min="0" step="1" name="cassette_{denom}" id="cassette_{denom}" value="{val}">
            </div>
        """
    html += """
            <div class="btn-row">
              <button type="submit" class="btn">💾 Save</button>
              <a href="/" class="back-link">&larr; Back</a>
            </div>
          </form>
        </div>
      </div>
    </body>
    </html>
    """
    return html

@dashboard_flask_app.route('/api/reset-stats', methods=['POST'])
@require_login
def reset_stats():
    fresh_data = load_data_from_file()
    # Reset coins and banknotes in the box
    fresh_data["coins inside the box"] = {k: 0 for k in fresh_data["coins inside the box"]}
    fresh_data["banknotes inside the box"] = {k: 0 for k in fresh_data["banknotes inside the box"]}
    
    # Reset total values
    fresh_data["total coins value in the box"] = 0
    fresh_data["total banknotes value in the box"] = 0
    fresh_data["total physical money value in the box"] = 0
    fresh_data["customer transferred amount"] = 0
    
    save_data_to_file(fresh_data)
    print("=== Statistics reset! ===")
    return jsonify({"message": "Statistics reset complete!"})

#if __name__ == '__main__':
#    app.run(host='0.0.0.0', port=8000)
