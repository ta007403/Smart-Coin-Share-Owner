import serial
import time  # Don't forget this if you use time.sleep

def delete_all_messages(ser, timeout=5):
    """
    Sends the 'DEL_ALL' command to Arduino via `ser` to delete all messages.
    Waits up to `timeout` seconds for Arduino responses. Returns a list of response lines.
    """
    ser.flushInput()  # Clear any old input
    ser.write(b'DEL_ALL\n')
    print(">> Sent: DEL_ALL")

    response = []
    start = time.time()

    print("<< Waiting for response...")
    while time.time() - start < timeout:
        while ser.in_waiting:
            line = ser.readline().decode(errors='ignore').strip()
            if line:
                print("<<", line)
                response.append(line)
                # Optionally, break if you get a known "done" signal from Arduino:
                if "ALL_DELETED" in line or "OK" in line or "DONE" in line:
                    # Replace with your Arduino's real done/confirmation message!
                    return response
        time.sleep(0.1)

    if not response:
        print("No response from Arduino after DEL_ALL.")

    return response


def get_sms_count(ser, timeout=3):
    """
    Sends 'COUNT_STRING' command to Arduino to get SMS count.
    Waits for Arduino to respond with the count.
    Returns the count as an integer (or None if not found).
    """
    ser.flushInput()  # Clear old input
    ser.write(b'COUNT_STRING\n')
    print(">> Sent: COUNT_STRING")
    
    start = time.time()
    response_line = ""
    while time.time() - start < timeout:
        if ser.in_waiting:
            line = ser.readline().decode(errors='ignore').strip()
            print("<<", line)
            # Expecting a response like: "SMS_COUNT: 23"
            if "COUNT" in line:
                response_line = line
                break
        else:
            time.sleep(0.1)
    
    if not response_line:
        print("No response from Arduino for COUNT_STRING.")
        return None

    # Try to extract the count from Arduino's response
    import re
    match = re.search(r'(\d+)', response_line)
    if match:
        sms_count = int(match.group(1))
        print(f"SMS Count: {sms_count}")
        return sms_count
    else:
        print("Could not parse SMS count from response:", response_line)
        return None

# Example MAIN usage
if __name__ == "__main__":
    port = '/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0'
    baudrate = 9600
    ser = None
    try:
        ser = serial.Serial(port, baudrate, timeout=1)
        time.sleep(5)
        responses = delete_all_messages(ser)
        time.sleep(5)
        get_sms_count(ser)
        print("All responses:", responses)
    except Exception as e:
        print("Could not open serial port:", e)
    finally:
        if ser and ser.is_open:
            ser.close()
            print("Serial port closed.")
