BTC_THB = None         # Last fetched price
SATS_PER_THB = None    # Last fetched sats per baht