from typing import Iterable, List, Optional, Tuple, Union
from urllib.parse import urlparse
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtWidgets import QLabel
import qrcode
import re

CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"

def bech32_polymod(values: Iterable[int]) -> int:
    """Internal function that computes the Bech32 checksum."""
    generator = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3]
    chk = 1
    for value in values:
        top = chk >> 25
        chk = (chk & 0x1ffffff) << 5 ^ value
        for i in range(5):
            chk ^= generator[i] if ((top >> i) & 1) else 0
    return chk

def bech32_hrp_expand(hrp: str) -> List[int]:
    """Expand the HRP into values for checksum computation."""
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]

def bech32_verify_checksum(hrp: str, data: Iterable[int]) -> bool:
    """Verify a checksum given HRP and converted data characters."""
    return bech32_polymod(bech32_hrp_expand(hrp) + list(data)) == 1

def bech32_create_checksum(hrp: str, data: Iterable[int]) -> List[int]:
    """Compute the checksum values given HRP and data."""
    values = bech32_hrp_expand(hrp) + list(data)
    polymod = bech32_polymod(values + [0, 0, 0, 0, 0, 0]) ^ 1
    return [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]

def bech32_encode(hrp: str, data: Iterable[int]) -> str:
    """Compute a Bech32 string given HRP and data values."""
    combined = list(data) + bech32_create_checksum(hrp, data)
    return hrp + "1" + "".join([CHARSET[d] for d in combined])

def bech32_decode(bech: str) -> Union[Tuple[None, None], Tuple[str, List[int]]]:
    """Validate a Bech32 string, and determine HRP and data."""
    if (any(ord(x) < 33 or ord(x) > 126 for x in bech)) or (
        bech.lower() != bech and bech.upper() != bech
    ):
        return (None, None)
    bech = bech.lower()
    pos = bech.rfind("1")
    if pos < 1 or pos > 83 or pos + 7 > len(bech):  # or len(bech) > 90:
        return (None, None)
    if not all(x in CHARSET for x in bech[pos + 1 :]):
        return (None, None)
    hrp = bech[:pos]
    data = [CHARSET.find(x) for x in bech[pos + 1 :]]
    if not bech32_verify_checksum(hrp, data):
        return (None, None)
    return (hrp, data[:-6])

def convertbits(data: Iterable[int], frombits: int, tobits: int, pad: bool = True) -> Optional[List[int]]:
    """General power-of-2 base conversion."""
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return ret

def decode(hrp: str, addr: str) -> Union[Tuple[None, None], Tuple[int, List[int]]]:
    """Decode a segwit address."""
    hrpgot, data = bech32_decode(addr)
    if hrpgot != hrp:
        return (None, None)
    assert data is not None
    decoded = convertbits(data[1:], 5, 8, False)
    if decoded is None or len(decoded) < 2 or len(decoded) > 40:
        return (None, None)
    if data[0] > 16:
        return (None, None)
    if data[0] == 0 and len(decoded) != 20 and len(decoded) != 32:
        return (None, None)
    return (data[0], decoded)

def encode(hrp: str, witver: int, witprog: Iterable[int]) -> Optional[str]:
    """Encode a segwit address."""
    five_bit_witprog = convertbits(witprog, 8, 5)
    if five_bit_witprog is None:
        return None
    ret = bech32_encode(hrp, [witver] + five_bit_witprog)
    if decode(hrp, ret) == (None, None):
        return None
    return ret

# This function just parse LNURL to be Lightning Wallet Address
# Not go to the internet
def parse_lnurl(qr_string: str) -> str:
    hrp, data = bech32_decode(qr_string.lower())
    if hrp != "lnurl" or data is None:
        raise ValueError("Invalid LNURL")
    
    decoded_bytes = convertbits(data, 5, 8, False)
    if decoded_bytes is None:
        raise ValueError("Bit conversion failed")
    
    url = bytes(decoded_bytes).decode("utf-8")
    print("[*] Decoded URL:", url)

    parsed = urlparse(url)
    domain = parsed.netloc
    parts = parsed.path.strip("/").split("/")
    # Try to extract username@domain for well-known lnaddress
    if len(parts) >= 3 and parts[0] == ".well-known" and parts[1] == "lnurlp":
        username = parts[2]
        return f"{username}@{domain}"
    # Try Voltage and other providers' format /lnurlp/<username>
    elif len(parts) >= 2 and parts[0] == "lnurlp":
        username = parts[1]
        return f"{username}@{domain}"
    # If not matched, return the URL itself
    else:
        return url

def now_string():
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def mask_card_number(cardnum):
    return '*' * (len(cardnum)-4) + cardnum[-4:]

def strip_http_prefix(address: str) -> str:
    # Python 3.9+ only
    address = address.removeprefix("http://")
    address = address.removeprefix("https://")
    return address

def generate_qr_pixmap(data, size=320, box_size=8, border=2):
    import qrcode
    from PyQt5.QtGui import QPixmap, QImage

    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=box_size,
        border=border,
    )
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img = img.convert("RGB")
    img = img.resize((size, size))  # Resize PIL image to 320x320
    width, height = img.size
    data_bytes = img.tobytes("raw", "RGB")
    qimg = QImage(data_bytes, width, height, QImage.Format_RGB888)
    return QPixmap.fromImage(qimg)

def split_text_in_half(text):
    length = len(text)
    chunk_size = length // 5
    lines = [text[i:i + chunk_size] for i in range(0, chunk_size * 5, chunk_size)]

    # Add the remainder (if any) to the last line
    remainder = text[chunk_size * 5:]
    if remainder:
        lines[-1] += remainder

    return "\n".join(lines)

def sum_banknote_value(note_stock):
    """Return the total value of all banknotes remaining."""
    total = sum(denom * qty for denom, qty in note_stock.items())
    return total

def extract_uid(text):
    # Replace <CR> with newline for easier line splitting
    lines = text.replace('<CR>', '\n').splitlines()
    
    # Regular expression for UID: 8 or more hex characters
    uid_pattern = re.compile(r'^[A-Fa-f0-9]{8,}$')
    
    for line in lines:
        line = line.strip()
        if uid_pattern.match(line):
            return line  # Return the first UID found
    
    return None  # Return None if no UID is found

def extract_lnurl_from_text(text):
    """Extract the LNURL from a string that may have 'lightning:' in front."""
    # Remove leading/trailing whitespace
    text = text.strip()
    # If it starts with 'lightning:', remove that part (case-insensitive)
    if text.lower().startswith("lightning:"):
        text = text[len("lightning:"):]
    # Remove any spaces just in case
    return text.strip()

def extract_only_one_lnurl(text):
    """
    Extract and return the first LNURL (bech32, starts with LNURL) from the text.
    Returns None if not found.
    """
    # LNURL format: starts with LNURL (case-insensitive), then A-Z0-9 (bech32), at least ~20 chars long
    pattern = re.compile(r'(LNURL[a-zA-Z0-9]{20,})', re.IGNORECASE)
    match = pattern.search(text)
    if match:
        return match.group(1)
    return None